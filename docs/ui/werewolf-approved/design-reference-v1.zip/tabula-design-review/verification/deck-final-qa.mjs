import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {execFileSync} from 'node:child_process';
import {roles,cardBack} from '../deck/cards.mjs';

const require=createRequire(import.meta.url);
const {chromium}=require('/Users/manhblue/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright-core');
const base='http://127.0.0.1:8063';
const inputs=['deck/cards.mjs','deck/cards.css','deck/gallery.mjs','werewolf/werewolf.mjs','werewolf/werewolf.css'];
const hash=text=>createHash('sha256').update(text).digest('hex');
const digestInputs=async()=>Object.fromEntries(await Promise.all(inputs.map(async path=>[path,hash(await fs.readFile(path))])));
const startInputs=await digestInputs();
const records=[],errors=[];
let assertions=0;
function check(condition,name,details={}){assertions++;assert.ok(condition,`${name}: ${JSON.stringify(details)}`);}
function record(name,details={}){records.push({name,status:'PASS',...details});}
function observeErrors(page){page.on('pageerror',error=>errors.push(String(error)));page.setDefaultTimeout(7000);}
async function cardBounds(page,selector){return page.locator(selector).evaluate(e=>{
 const card=e.getBoundingClientRect();
 const text=[...e.querySelectorAll('.deck-copy h2,.deck-copy p,.deck-faction,.deck-footer')].map(node=>{
  const r=node.getBoundingClientRect();return {tag:node.tagName,text:node.textContent,font:getComputedStyle(node).fontSize,inside:r.left>=card.left&&r.right<=card.right&&r.top>=card.top&&r.bottom<=card.bottom,scroll:node.scrollHeight,client:node.clientHeight};
 });
 return {width:card.width,height:card.height,text,documentWidth:document.documentElement.scrollWidth,viewportWidth:document.documentElement.clientWidth};
});}
async function concealed(page,selector,snapshotName){
 const dom=await page.locator(selector).evaluate(e=>({html:e.outerHTML,fronts:e.querySelectorAll('.deck-front,.deck-art,.deck-faction,[data-role]').length,roleAttributes:[...e.querySelectorAll('*')].flatMap(n=>[...n.attributes]).filter(a=>/data-role|data-faction/.test(a.name)).length,images:e.querySelectorAll('img').length,bg:getComputedStyle(e).backgroundColor}));
 check(dom.fronts===0&&dom.roleAttributes===0&&dom.images===0,'Concealed card has no face, faction or role attribute',{selector,dom});
 check(dom.bg==='rgb(33, 31, 51)','Common back is opaque',{bg:dom.bg});
 const snapshot=await page.evaluate(name=>window[name].snapshot(),snapshotName);
 check(snapshot.revealed===false&&!('role' in snapshot)&&!('ownRole' in snapshot),'Concealed review snapshot omits own role',snapshot);
 return dom;
}

const canonicalBack=cardBack();
check(roles.length===6&&new Set(roles.map(x=>x.key)).size===6,'Six distinct base roles');
for(const role of roles){
 check(cardBack({role:role.key,faction:role.faction})===canonicalBack,'Common back bytes identical',role);
 const file=await fs.readFile(`deck/${role.key.toLowerCase()}.png`);
 check(file.readUInt32BE(16)===960&&file.readUInt32BE(20)===1440,'Front PNG export dimensions',{role:role.key,width:file.readUInt32BE(16),height:file.readUInt32BE(20)});
}
const backPng=await fs.readFile('deck/back.png');
check(backPng.readUInt32BE(16)===960&&backPng.readUInt32BE(20)===1440,'Back PNG export dimensions');
record('Deck coverage, identical back bytes, seven PNG dimensions',{roles:roles.map(x=>x.key),outputPixels:[960,1440],backSha256:hash(canonicalBack)});

const b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:false});
try{
 for(const width of [320,390]){
  for(const role of roles){
   const page=await b.newPage({viewport:{width,height:844},deviceScaleFactor:1});observeErrors(page);
   const atlasRequests=[];page.on('request',request=>{if(request.url().includes('werewolf-role-art-atlas'))atlasRequests.push(request.url())});
   await page.goto(`${base}/deck/?mobile=${role.key}`,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.deckReady);await page.evaluate(()=>document.fonts.ready);
   const initial=await concealed(page,'.deck-back','deckReview');
   check(atlasRequests.length===0,'No art atlas request before reveal',{width,role:role.key,requests:atlasRequests});
   await page.locator('[data-action="reveal"]').focus();await page.keyboard.press('Enter');
   check(await page.locator('.deck-front').getAttribute('data-role')===role.key,'Keyboard reveal shows requested review role',{width,role:role.key});
   const bounds=await cardBounds(page,'.deck-front');
   check(bounds.documentWidth<=bounds.viewportWidth,'Deck mobile document fits viewport',bounds);
   check(bounds.text.every(x=>x.inside&&x.scroll<=x.client+1),'Deck live Vietnamese card text fits',bounds);
   await page.locator('[data-action="select"]').focus();await page.keyboard.press('Enter');
   const selection=await page.locator('.deck-front').evaluate(e=>({selected:e.classList.contains('is-selected'),label:e.querySelector('.selection-label')?.textContent,outline:getComputedStyle(e).outlineWidth}));
   check(selection.selected&&selection.label?.includes('Đang chọn')&&selection.outline==='4px','Selection has outline and text affordance',selection);
   if(width===320&&role.key==='Witch')await page.screenshot({path:'previews/deck-final-qa-mobile-320.png',fullPage:true});
   await page.keyboard.press('Escape');await concealed(page,'.deck-back','deckReview');
   check(await page.locator('[data-action="reveal"]').evaluate(e=>e===document.activeElement),'Escape returns focus to reveal control');
   record('Mobile deck keyboard reveal/select/Escape and text bounds',{width,role:role.key,bounds,initialAtlasRequests:0,initialBackHash:hash(initial.html),selectedBackDoesNotRevealRole:true});
   await page.close();
  }
  const page=await b.newPage({viewport:{width,height:844},deviceScaleFactor:1});observeErrors(page);
  await page.goto(`${base}/werewolf/`);await page.waitForFunction(()=>window.designReview);await page.evaluate(()=>document.fonts.ready);
  const publicNightHashes=[];
  for(const role of roles){
   await page.evaluate(key=>{designReview.setScenario('night');designReview.setRole(key)},role.key);
   await concealed(page,'.private-panel .deck-back','designReview');
   const publicBefore=await page.locator('#public-night').evaluate(e=>e.outerHTML);
   await page.locator('[data-action="reveal-role"]').focus();await page.keyboard.press('Enter');
   check(await page.locator('.private-panel .deck-front').getAttribute('data-role')===role.key,'Werewolf private role revealed by keyboard',{width,role:role.key});
   const bounds=await cardBounds(page,'.private-panel .deck-front');
   check(bounds.documentWidth<=bounds.viewportWidth,'Werewolf mobile document fits viewport',bounds);
   check(bounds.text.every(x=>x.inside&&x.scroll<=x.client+1),'Werewolf Vietnamese skill fits card',bounds);
   const publicAfter=await page.locator('#public-night').evaluate(e=>e.outerHTML);
   check(publicBefore===publicAfter,'Own-role reveal leaves public Night DOM byte-identical',{width,role:role.key});
   publicNightHashes.push(hash(publicAfter));
   if(width===320&&role.key==='Witch')await page.screenshot({path:'previews/deck-final-qa-werewolf-320.png',fullPage:true});
   await page.keyboard.press('Escape');await concealed(page,'.private-panel .deck-back','designReview');
   check(await page.locator('[data-action="reveal-role"]').evaluate(e=>e===document.activeElement),'Werewolf Escape restores reveal focus');
   record('Werewolf private role keyboard reveal/Escape, mobile bounds, stable public Night DOM',{width,role:role.key,bounds,publicNightHash:hash(publicAfter)});
  }
  check(new Set(publicNightHashes).size===1,'All six own roles leave public Night DOM identical',{width,publicNightHashes});
  await page.evaluate(()=>{designReview.setRole('Witch');designReview.setScenario('night')});
  await page.locator('[data-action="reveal-role"]').click();await page.locator('[data-private-target="1"]').click();
  check(await page.evaluate(()=>designReview.snapshot().target)===1,'Private target fixture is reachable');
  await page.evaluate(()=>designReview.setScenario('reconnect'));
  const reconnect=await page.evaluate(()=>designReview.snapshot());
  check(!reconnect.revealed&&reconnect.target===null&&!('ownRole' in reconnect)&&await page.locator('.deck-front').count()===0,'Reconnect clears private card and target',reconnect);
  record('Werewolf reconnect clears private card and selection',{width});
  await page.close();
 }
 check(errors.length===0,'No JavaScript page errors',{errors});
 const endInputs=await digestInputs();
 check(JSON.stringify(startInputs)===JSON.stringify(endInputs),'Verified source files stayed unchanged during check',{startInputs,endInputs});
 await fs.writeFile('verification/deck-final-qa.json',JSON.stringify({status:'PASS',executedAt:new Date().toISOString(),command:'node verification/deck-final-qa.mjs',cwd:process.cwd(),browser:b.version(),driver:'Playwright 1.62.1, actual headed Chrome; localhost HTTP; deviceScaleFactor 1; keyboard and mouse input',sourceRepoHead:execFileSync('git',['-C','../tabula','rev-parse','HEAD'],{encoding:'utf8'}).trim(),sourceHashes:endInputs,assertions,records,errors,skillCopyAudit:{status:'source-read',authority:'tabula/docs/games/werewolf.md:95–132 and games/werewolf/src/rules/role.rs:19–52',summary:'Six names/factions and concise skills match ClassicV1. Hunter precommits rather than reactive shot; Witch blind heal, one heal and one poison, at most one per Night; Doctor self-protect and no consecutive same target, wolf-only; Seer alignment only at Dawn; Villager no Night action; wolves know teammates but not live choices.',abbreviations:'Card summaries are concise, not full rulebooks: Doctor passing clears prior target; Hunter mark persists through round Vote; Witch may target self and consumes potion on submission even if ineffective. Detailed game controls retain these semantics where presented.'},limits:['Isolated review mock: no Rust reducer, permitted View integration, real match transport, canonical state, production secrecy proof, or phase gate completion.','Full generic deck definitions and artwork atlas exist in review JavaScript/assets; concealed DOM assertions cover the rendered card only.','No automated preload was used for before-reveal request checks. A fresh review page made no atlas request until reveal; this is not an asset-authorization security boundary.','Keyboard/mouse at emulated mobile viewport, not physical touch device. Safari/WebKit, native runtime, real OS blur/visibility handoff and screen-reader usability were not exercised in this check.','Screenshot capture is recorded separately from visual inspection; these tests verify DOM/layout bounds, not complete visual acceptance.']},null,2)+'\n');
 console.log(JSON.stringify({status:'PASS',assertions,records:records.length,browser:b.version(),errors}));
}catch(error){await fs.writeFile('verification/deck-final-qa.json',JSON.stringify({status:'FAIL',executedAt:new Date().toISOString(),assertions,records,errors,error:String(error)},null,2)+'\n');throw error;}
finally{await b.close()}
