# Verification —04.10 design revision

Pinned source: `c0a62088c159cc1f20409de41af245c98dcfcfee`, clean repository.
The03.10 folder remains the prior review. Its broader simulated-state test receipts
are not claimed as rerun against this revision.

Actual headed Chrome154.0.8037.97, existing Playwright1.62.1, Node22.15 on this Mac:

- `shared-shell-capture.json`:12 dashboard/Caro viewport observations at1440,
  390 and320px plus three keyboard launch/return checks.
- `shared-werewolf-capture.json`: eight entry/setup/lobby/launch observations at
  1440 and390px plus two keyboard launch/return checks.
- Common scenes use surface#FFFBFF / primary#5634BE with no story images;
  game scenes use their own palette. No horizontal document overflow/page errors.
- `deck-capture.json`: seven real HTML/CSS exports at320×480 CSS / DPR3, six fronts
  plus shared back, and the three mobile concealed/revealed/selected captures.
- `deck-final-qa.json`: focused interaction/privacy-DOM checks and exact scope.
- `source-package-receipt.json`: source ZIP integrity, local references and byte counts; per-package source manifests
  and `assets/asset-manifest.json` provide SHA-256 evidence.

All screenshots are local review fixtures. The export harness intentionally preloads
the atlas for deterministic pixels; its network trace does not establish private
asset security. A front being absent from this fixture's DOM is not proof of server
projection, timing privacy or resistance to inspecting bundled review definitions.

Not run: production game/rules, Rust/WASM bridge, multiplayer, actual projection,
Safari/WebKit, native gameplay, physical touch, assistive technology or OS focus
transitions. There is no GPU/performance comparison in this design revision. Existing
motion preference remains a review control; real platform preference integration
requires separate implementation verification. No repository commit, push or deploy.

The lightweight source ZIPs omit all PNG exports and preview captures. To rerun the
deck QA from extracted source, copy the seven unchanged PNGs from
`werewolf-role-png-assets.zip` (`werewolf-role-pngs/`) into source `deck/` first.
Browser capture scripts record the installed driver and Chrome paths on this Mac;
adapt those paths for another environment. `package-source.py` builds from the complete
local review workspace (including retained original PNGs), rather than from one
lightweight package. Extract both source ZIPs into the same directory for both
dashboard links. A single source ZIP supports its own game route directly.
