import fs from 'node:fs/promises';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {chromium}=require('/Users/manhblue/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright-core');
const b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:false});
const records=[];const errors=[];
try {
 for(const viewport of [{width:1440,height:1000},{width:390,height:844}]){
  const p=await b.newPage({viewport,deviceScaleFactor:1});p.on('pageerror',e=>errors.push(String(e)));
  await p.goto('http://127.0.0.1:8063/werewolf/');await p.waitForFunction(()=>window.designReview);
  for(const scenario of ['entry','setup','lobby','reveal']){
   await p.evaluate(s=>designReview.setScenario(s),scenario);
   await p.evaluate(async()=>{await document.fonts.ready;await Promise.all([...document.images].map(i=>i.decode()))});
   const observed=await p.evaluate(()=>({surface:document.body.dataset.surface,theme:document.body.dataset.theme,bg:getComputedStyle(document.body).backgroundColor,primary:getComputedStyle(document.body).getPropertyValue('--primary').trim(),documentWidth:document.documentElement.scrollWidth,viewportWidth:document.documentElement.clientWidth,storyImages:[...document.images].filter(i=>i.src.includes('hero')).length}));
   if(observed.documentWidth>observed.viewportWidth+1)throw new Error('Document overflow: '+JSON.stringify({scenario,viewport,observed}));
   const expected=scenario==='reveal'?'game':'shell';if(observed.surface!==expected)throw new Error('Wrong surface: '+JSON.stringify({scenario,observed}));
   if(expected==='shell'&&(observed.bg!=='rgb(255, 251, 255)'||observed.primary!=='#5634BE'||observed.storyImages!==0))throw new Error('Wrong common theme/art boundary: '+JSON.stringify({scenario,observed}));
   if(expected==='game'&&(observed.bg!=='rgb(20, 18, 23)'||observed.primary!=='#CFBCFF'))throw new Error('Wrong launched game palette: '+JSON.stringify({scenario,observed}));
   await p.screenshot({path:`previews/shared-werewolf-${scenario}-${viewport.width===1440?'desktop':'phone'}.png`,fullPage:true});records.push({scenario,viewport,...observed});
  }
  await p.evaluate(()=>designReview.setScenario('lobby'));await p.locator('[data-action="reveal"]').focus();await p.keyboard.press('Enter');if(await p.evaluate(()=>document.body.dataset.surface)!=='game')throw new Error('Keyboard launch failed');
  await p.locator('.shared-brand').click();await p.waitForSelector('.catalog-card');if(await p.evaluate(()=>document.body.dataset.surface)!=='shell')throw new Error('Dashboard return failed');records.push({name:'keyboard-launch-and-dashboard-return',viewport,status:'PASS'});await p.close();
 }
 await fs.writeFile('verification/shared-werewolf-capture.json',JSON.stringify({status:errors.length?'FAIL':'PASS',browser:b.version(),driver:'Existing Playwright 1.62.1, headed Chrome',records,errors},null,2)+'\n');if(errors.length)throw new Error(errors.join('\n'));
}finally{await b.close()}
