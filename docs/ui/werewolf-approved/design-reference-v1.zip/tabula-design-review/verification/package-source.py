#!/usr/bin/env python3
"""Package review source with stdlib-only size/hash/reference evidence.

Run from the complete local review workspace. This never changes product source,
does not edit image pixels, and makes no production asset/security claims.
"""
import hashlib
import json
import posixpath
import re
import struct
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
BASE_SHA = "c0a62088c159cc1f20409de41af245c98dcfcfee"
ARCHIVE_ROOT = "tabula-design-review/"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    (ROOT / path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def dimensions(data):
    """Read PNG/WebP header metadata only; no image decode or modification."""
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        assert data[12:16] == b"IHDR"
        return struct.unpack(">II", data[16:24])
    assert data[:4] == b"RIFF" and data[8:12] == b"WEBP", "Unsupported asset format"
    offset = 12
    while offset + 8 <= len(data):
        kind = data[offset:offset + 4]
        size = int.from_bytes(data[offset + 4:offset + 8], "little")
        body = data[offset + 8:offset + 8 + size]
        if kind == b"VP8X":
            return (1 + int.from_bytes(body[4:7], "little"),
                    1 + int.from_bytes(body[7:10], "little"))
        if kind == b"VP8 ":
            assert body[3:6] == b"\x9d\x01\x2a"
            return tuple(x & 0x3fff for x in struct.unpack("<HH", body[6:10]))
        if kind == b"VP8L":
            assert body[0] == 0x2f
            bits = int.from_bytes(body[1:5], "little")
            return (1 + (bits & 0x3fff), 1 + ((bits >> 14) & 0x3fff))
        offset += 8 + size + (size & 1)
    raise ValueError("WebP dimensions missing")


def file_record(path):
    data = (ROOT / path).read_bytes()
    return {"path": path, "bytes": len(data), "sha256": sha(data)}


def asset_record(game, path, kind, purpose, provenance, in_source):
    record = file_record(path)
    width, height = dimensions((ROOT / path).read_bytes())
    return {"game": game, **record, "kind": kind, "width": width, "height": height,
            "decoded_rgba8_bytes": width * height * 4,
            "purpose": purpose, "provenance": provenance,
            "third_party_art_imported": False, "included_in_source_zip": in_source}


assets = []
for game in ("caro", "werewolf"):
    for path, kind, included in [
        (f"assets/originals/{game}-hero.png", "built-in imagegen original", False),
        (f"assets/{game}-hero.webp", "WebP q88 derivative", True),
    ]:
        assets.append(asset_record(game, path, kind,
            "Public decorative in-game story artwork; never rules or private assignment data",
            "Built-in imagegen 2026-10-03; exact prompt in assets/prompts-provenance.json", included))
for path, kind, included in [
    ("assets/originals/werewolf-role-art-atlas.png", "built-in imagegen original", False),
    ("assets/werewolf-role-art-atlas.webp", "WebP q88 derivative", True),
]:
    record = asset_record("werewolf", path, kind,
        "Six generic role portraits for isolated design review; exclude full atlas from public gameplay projection",
        "Built-in imagegen 2026-10-04; exact prompt/references in assets/deck-provenance.json", included)
    record["panels"] = {"columns": 3, "rows": 2, "width": 512, "height": 512,
                        "order": ["Villager", "Werewolf", "Seer", "Doctor", "Hunter", "Witch"]}
    assets.append(record)
for key in ("villager", "werewolf", "seer", "doctor", "hunter", "witch", "back"):
    record = asset_record("werewolf", f"deck/{key}.png", "Actual Chrome HTML/CSS export at DPR3",
        "Individual front/common-back review asset, not player role assignment",
        "Original atlas + editable authored frame/back and live Vietnamese text; deck-capture.json", False)
    assert (record["width"], record["height"]) == (960, 1440)
    record["portrait_detail_limit"] = "512x512 original panel; export density does not add portrait detail"
    assets.append(record)

common_meta = {
    "date": "2026-10-04", "source_base": BASE_SHA,
    "code_native": ["X/O and board coordinates", "SVG interface symbols", "HTML/CSS card frame",
                    "SVG common card back", "selection outline and label", "Vietnamese live text"],
    "fonts": "System stack only; no bundled/downloaded font",
    "theme": "Dashboard/discovery/setup/lobby: shared Tabula light scheme. Bespoke story palettes begin after launch; game extensions remain review proposals.",
    "originals_distribution": "Original PNGs retained locally outside lightweight source ZIPs; seven card PNGs delivered separately",
    "authority": "Isolated design fixture; no Rust reducer, permitted View integration, match socket or production renderer/embedding migration",
    "decoded_cost_note": "RGBA8 width*height*4 estimates only; no measured GPU allocation or runtime decode benchmark",
}
write_json("assets/asset-manifest.json", {**common_meta, "assets": assets})
for game in ("caro", "werewolf"):
    selected = [x for x in assets if x["game"] == game]
    write_json(f"assets/{game}-manifest.json", {"game": game, **common_meta, "assets": selected,
        "zip_assets_included": [x["path"] for x in selected if x["included_in_source_zip"]],
        "original_png_in_zip": False, "preview_or_card_export_png_in_zip": False})

common = ["README.md", "implementation-handoff.md", "contracts-audit.md", "index.html",
          "assets/asset-manifest.json", "assets/prompts-provenance.json",
          "verification/README.md", "verification/package-source.py",
          "verification/comparison-capture.json", "verification/capture-comparison.mjs"]
common += [p.relative_to(ROOT).as_posix() for p in sorted((ROOT / "shared").iterdir()) if p.is_file()]
package_files = {}
for game in ("caro", "werewolf"):
    own = [p.relative_to(ROOT).as_posix() for p in sorted((ROOT / game).iterdir()) if p.is_file()]
    own += [f"assets/{game}-manifest.json", f"assets/{game}-hero.webp"]
    if game == "caro":
        own += ["verification/capture-shell.mjs", "verification/shared-shell-capture.json"]
    else:
        own += ["assets/deck-provenance.json", "assets/werewolf-role-art-atlas.webp"]
        own += [f"deck/{name}" for name in ("index.html", "cards.css", "cards.mjs", "gallery.mjs")]
        own += [f"verification/{name}" for name in (
            "shared-werewolf-capture.mjs", "shared-werewolf-capture.json", "capture-deck.mjs",
            "deck-capture.json", "deck-final-qa.mjs", "deck-final-qa.json",
            "capture-mobile-states.mjs", "mobile-states-capture.json")]
    package_files[game] = sorted(set(common + own))


def local_reference_checks(game, files):
    """Check literal runtime imports/styles/images; expanded common navigation is explicit."""
    file_set = set(files)
    checked = []
    remote = []
    dynamic = []
    for name in files:
        if Path(name).suffix not in (".mjs", ".css", ".html") or name.startswith("verification/"):
            continue
        source = (ROOT / name).read_text()
        refs = re.findall(r"\b(?:from|import)\s*(?:\(\s*)?['\"]([^'\"]+)['\"]", source)
        refs += re.findall(r"\b(?:src|href)\s*=\s*['\"]([^'\"]+)['\"]", source)
        refs += re.findall(r"\burl\(\s*['\"]?([^)'\"\s]+)", source)
        for ref in refs:
            if "${" in ref:
                dynamic.append({"source": name, "reference": ref})
                continue
            parsed = urlsplit(ref)
            if parsed.scheme or parsed.netloc:
                if parsed.scheme not in ("data",):
                    remote.append({"source": name, "reference": ref})
                continue
            if not parsed.path:
                continue
            target = posixpath.normpath(posixpath.join(posixpath.dirname(name), parsed.path))
            assert target in file_set, f"Unresolved {game} runtime reference {name}: {ref} -> {target}"
            checked.append({"source": name, "reference": ref, "target": target})
    assert not remote, f"Unexpected external runtime references: {remote}"
    assert "index.html" in file_set and f"{game}/index.html" in file_set
    shell = (ROOT / "shared/shell.mjs").read_text()
    assert 'href="${key}/index.html"' in shell
    return {"status": "PASS", "literal_references_checked": checked,
            "dynamic_templates_source_read": dynamic,
            "navigation": {"own_route": f"{game}/index.html", "own_route_present": True,
                           "companion_route": f"{'werewolf' if game == 'caro' else 'caro'}/index.html",
                           "companion_requires_both_packages": True},
            "scope": "Static literal HTML/CSS/module/image references only; browser runtime evidence recorded separately"}


qa = json.loads((ROOT / "verification/deck-final-qa.json").read_text())
assert qa["status"] == "PASS" and qa["assertions"] == 298
for path, expected in qa["sourceHashes"].items():
    assert file_record(path)["sha256"] == expected, f"QA source changed: {path}"
receipt = {"status": "PASS", "executed_at": datetime.now(timezone.utc).isoformat(),
           "command": "python3 verification/package-source.py", "source_base": BASE_SHA,
           "archive_root": ARCHIVE_ROOT, "deck_qa_source_hashes_unchanged": True,
           "excluded": ["original PNGs", "all standalone PNG exports", "preview images", "logs", "private Library receipts"],
           "packages": {}}
(ROOT / "deliverables").mkdir(exist_ok=True)
for game, files in package_files.items():
    references = local_reference_checks(game, files)
    manifest_name = f"verification/{game}-source-manifest.json"
    records = [file_record(name) for name in files]
    write_json(manifest_name, {"game": game, "date": "2026-10-04", "source_base": BASE_SHA,
        "archive_root": ARCHIVE_ROOT, "files": records,
        "manifest_self_hash_omitted": True, "local_runtime_references": references,
        "browser_verification": "Included JSON receipts describe actual headed Chrome review checks; not multiplayer/security/phase acceptance"})
    files = sorted(files + [manifest_name])
    out = ROOT / "deliverables" / f"{game}-review.zip"
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in files:
            info = zipfile.ZipInfo(ARCHIVE_ROOT + name, date_time=(2026, 10, 4, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, (ROOT / name).read_bytes(), compresslevel=9)
    with zipfile.ZipFile(out) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(files)
        for name in files:
            assert archive.read(ARCHIVE_ROOT + name) == (ROOT / name).read_bytes()
        assert not any(name.endswith(".png") or "/previews/" in name or name.endswith(".log") or "library" in name.lower()
                       for name in archive.namelist())
    receipt["packages"][game] = {**file_record(f"deliverables/{game}-review.zip"),
        "entries": len(files), "uncompressed_bytes": sum((ROOT / name).stat().st_size for name in files),
        "integrity": "PASS", "source_bytes_match": True,
        "manifest": manifest_name, "local_runtime_reference_status": references["status"],
        "included_webp_bytes": sum(x["bytes"] for x in assets if x["game"] == game and x["included_in_source_zip"])}
with zipfile.ZipFile(ROOT / "deliverables/caro-review.zip") as caro, zipfile.ZipFile(ROOT / "deliverables/werewolf-review.zip") as wolf:
    overlap = sorted(set(caro.namelist()) & set(wolf.namelist()))
    assert all(caro.read(name) == wolf.read(name) for name in overlap)
receipt["shared_archive_files_byte_identical"] = {"status": "PASS", "count": len(overlap), "paths": overlap}
write_json("verification/source-package-receipt.json", receipt)
print(json.dumps({"status": receipt["status"], "packages": receipt["packages"],
                  "shared_files_byte_identical": len(overlap), "assets_hashed": len(assets)}, ensure_ascii=False))
