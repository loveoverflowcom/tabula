> Audit carried forward from the03.10 review at the same pinned source. The04.10
> six-role card copy was additionally checked against ClassicV1. Current runtime
> receipts are in verification/README.md; prior runtime counts are not rerun claims.

# Kiểm tra hợp đồng thiết kế — Caro và Ma sói

Ngày 2026-10-03. Nguồn được đọc tại `loveoverflowcom/tabula`, commit
`c0a62088c159cc1f20409de41af245c98dcfcfee`. Đây là kiểm tra nguồn để chuẩn bị
**bản thiết kế mô phỏng**, không chứng nhận trò chơi chạy được, bảo mật mạng,
hoàn thành phase hay chuyển renderer. Kho `tabula` không được chỉnh sửa trong
lần kiểm tra này.

## Kết luận cho người review

Hai gói có thể minh họa luồng vào bàn, hành động, kết quả và phục hồi bằng
HTML/CSS/JS. Tất cả dữ liệu, đồng hồ, phiếu và kết quả là mẫu để review.
Caro chưa có reducer hay biến thể luật chốt. Ma sói đã có cấu hình, sáu vai,
kiểu trạng thái/sự kiện và phân vai ban đầu, nhưng chưa có reducer,
`View`/projection hay presenter. Không thể biến dữ liệu canonical hiện có
thành một “projection tạm” cho giao diện.

Đánh dấu xuyên suốt UI: **“Bản thiết kế mô phỏng · chưa phải trò chơi nhiều
người”**. Công cụ đổi scenario/vai là công cụ review, không phải quyền của
người chơi hoặc quản trò trong một trận thật.

## Nguồn, hiện trạng và phase

| Bề mặt | Hiện trạng đã đọc | Nguồn tại commit trên |
|---|---|---|
| Caro | Placeholder; không có `GameRules`, `GameModule`, `View`, `game.toml`, bot, presenter, conformance hay replay | [`games/caro/src/lib.rs:3–74`](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/caro/src/lib.rs#L3), [`docs/ui/screens/05-caro.md:10–20`](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/ui/screens/05-caro.md#L10) |
| Ma sói | Config, roles, validated canonical state/events, deterministic initial assignment, metadata/capabilities: implemented; reducer/projector/presenter: missing | [`games/werewolf/src/rules/mod.rs:16–140`](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/werewolf/src/rules/mod.rs#L16), [`games/werewolf/src/lib.rs:115–207`](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/werewolf/src/lib.rs#L115), [`docs/ui/screens/07-werewolf.md:11–25`](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/ui/screens/07-werewolf.md#L11) |
| Catalog/setup | ADR-0028 discovery/setup slice links Chess and Tiles; it does not launch Caro or Werewolf | [`crates/tabula-registry/src/lib.rs:183–201`](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/crates/tabula-registry/src/lib.rs#L183) |
| Phase 3 | Caro local implementation and Werewolf headless rules/projection/security remain requirements; no exit established by these designs | [`docs/architecture/07-phases-and-implementation-roadmap.md:185–222`](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/architecture/07-phases-and-implementation-roadmap.md#L185) |
| Ma sói social/voice | Presentation + social + online: Phase 7, after Phase 4/5. Voice: Phase 8 | [`docs/games/werewolf.md:24–34`](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/games/werewolf.md#L24) |
| Renderer/embedding | Macroquad remains production renderer. New ADR-0029 retains existing ADR-011 separate Leptos/game WASM documents. Pixi/iframe are isolated experiments, production choice deferred | [`docs/architecture/00-architecture-principles.md:683–702`](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/architecture/00-architecture-principles.md#L683), [`docs/adr/0029-renderer-embedding-spike.md:35–64`](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/adr/0029-renderer-embedding-spike.md#L35) |

Declared Cargo features and catalog capabilities do not establish functioning
consumers. `rg` over both game trees found no implemented `GameRules`,
`GameModule`, `apply`, `project`, `view_event`, `GamePresentation`, or
`projection_security!`. Werewolf `Event` currently contains only
`RolesAssigned` and `PhaseChanged` ([event.rs:19–34](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/werewolf/src/rules/event.rs#L19)).

## Caro: đề xuất hình ảnh không chốt luật

- Perfect information: both seats see the full board. Even then, a future
  client receives a distinct game-owned `View`, never canonical `State`.
- Board size, fixed versus configurable dimensions, freestyle versus
  first-player restrictions remain unresolved. Exact-five, overlines and
  blocked-end treatment must not be implied as verified rules.
- The delivered prototype explicitly labels its **9×9 sample** and says actual
  rule dimensions are undecided. A 15×15 sample would equally be an illustration,
  not a current preset. Label such a sample
  **“Bàn mẫu 15×15 · biến thể chờ chốt”** or describe its sample dimensions
  beside the setup choice. If review chooses another size, keep that equally
  explicit. Do not add Renju, ranked, clock, undo or matchmaking as functioning
  capabilities.
- Intended scope is alternating placement, four-direction win lines, full-board
  draw and local play; the `Place`/`Resign` names in `lib.rs` are illustrative
  sketches. A painted five-mark line does not constitute authoritative win
  detection. “Thắng” and “Hòa” scenarios must say they are sample results.
- Last move, turn and result eventually come from permitted view/events.
  Hover, focus, provisional cell selection, camera/zoom and motion remain local.
  The simulated review interaction must not be described as rule validation.
- On compact screens, a 15×15 grid produces cells smaller than 44 dp. Use
  nearest-cell disambiguation plus an explicit coordinate/confirm step, zoom,
  or another reviewed scheme; do not pretend 225 overlapping 44 dp targets are
  independently usable. X/O and seat labels complement color.

Sources: [Caro design:15–38](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/games/caro.md#L15),
[crate sketch:15–59](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/caro/src/lib.rs#L15),
[UI contract:22–68](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/ui/screens/05-caro.md#L22).

## Ma sói: sáu vai ClassicV1

The closed source enum is `Villager`, `Werewolf`, `Seer`, `Doctor`, `Hunter`,
`Witch` ([role.rs:19–42](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/werewolf/src/rules/role.rs#L19)).
Vietnamese labels are presentation translations, not extra roles.

| UI label / source role | Luồng đêm hợp lệ theo hợp đồng | Guard for the design |
|---|---|---|
| Dân làng / Villager | No private night action | Waiting only; do not show a private Submit or Pass button. Existing state validation rejects Villager `NightChoice::Pass`. |
| Ma sói / Werewolf | Choose one living non-wolf target or pass; unique positive plurality decides attack; tie/all pass means none | Teammate identity may be known, but teammates' live targets and submission progress remain hidden. |
| Tiên tri / Seer | Investigate another living seat; receive private Wolf/NonWolf alignment at Dawn, even when target or Seer dies in that batch | No exact-role report; no immediate night result; cannot target self. |
| Bác sĩ / Doctor | Protect one living seat or pass; self allowed; no same target on consecutive nights; pass clears previous target | Blocks wolf attack only, never Witch poison; do not announce successful save. |
| Thợ săn / Hunter | Optional other-living-seat target selected **during Night**, retained through that round's Vote | No self target and no reactive target chooser after death. Retaliation triggers once before victory. |
| Phù thủy / Witch | One heal and one poison for whole match; at most one potion per Night, or pass; any living seat including self | **Blind heal**: no preview of wolf target/victim. Potion is consumed on submission even if ineffective. Poison ignores Doctor/heal protection. |

Mechanics above are maintained decisions, not executed reducer behavior:
[werewolf.md:93–132](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/games/werewolf.md#L93).
Role/target structural restrictions are present in
[state.rs:521–555](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/werewolf/src/rules/state.rs#L521),
with reconstructed-state examples in [tests/state.rs:402–448](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/werewolf/tests/state.rs#L402).
These validators do not implement potion consumption, resolution or repeated-night behavior.

### Setup must use exact ClassicV1 counts

Occupied seats are 6–20, unique, no preassigned teams. Counts are fixed by seat
count, not editable role sliders. Sorted seats are paired with the deterministic
shuffled multiset. If a review toolbar chooses a role, label it “Vai mẫu để
review”; the setup screen must not imply that players choose their assigned role.

| Seats | Wolves | Seer | Doctor | Hunter | Witch | Villagers |
|---|---:|---:|---:|---:|---:|---:|
| 6 | 1 | 1 | 1 | 0 | 0 | 3 |
| 8 | 2 | 1 | 1 | 1 | 0 | 3 |
| 10 | 2 | 1 | 1 | 1 | 1 | 4 |
| 12 | 3 | 1 | 1 | 1 | 1 | 5 |
| 20 | 5 | 1 | 1 | 1 | 1 | 11 |

The complete 6–20 table is authoritative in [role.rs:178–325](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/werewolf/src/rules/role.rs#L178)
and [werewolf.md:57–89](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/games/werewolf.md#L57).

### Phase, voting and reconnect

`Night → Dawn → Day discussion → Vote → Dusk → next Night`; `Ended` is terminal.
Defaults: 30 s / 2 s / 120 s / 30 s / 2 s respectively. Configurable duration
bounds are 1,000–600,000 ms; max rounds 1–100, default 100. Source types/defaults:
[state.rs:22–35](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/werewolf/src/rules/state.rs#L22),
[config.rs:30–52](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/werewolf/src/rules/config.rs#L30).

Day discussion and Vote are separate phases. Public ballots are replaceable;
abstain and unvote are supported concepts. Vote target must be another living
seat, not self. Default Plurality eliminates only the unique positive maximum;
ties eliminate nobody. AbsoluteMajority requires more than half of all living
seats, including abstainers. Uncast ballots default to abstain at expiry.
No phase closes early when everybody has acted/voted. A design countdown is
a simulated display, and future client clocks cannot trigger canonical phase
transitions. Sources: [werewolf.md:136–145](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/games/werewolf.md#L136),
[state.rs:482–505](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/games/werewolf/src/rules/state.rs#L482).

Connection changes do not stop phases, auto-kill seats or substitute humans/bots.
Previous choices remain; missing choices default at deadline; reconnect may act
before expiry. Clear private UI and lock command controls during context change
or recovery. Reconnect is a review scenario until the actual session adapter
exists. Sources: [werewolf.md:149–156](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/games/werewolf.md#L149),
[UI contract:44–67](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/ui/screens/07-werewolf.md#L44).

### Public/private boundaries and timing

| Viewer/surface | Permitted design content |
|---|---|
| Living seat | Public phase/deadline, liveness, public ballots, own role and own allowed choice/report. Other living roles hidden except wolf teammate identities. |
| Own role concealed | Remove secret text/art/labels from DOM and accessibility tree; concealment is local discretion, not a change in authorized knowledge. |
| Wolf | Own choice only; no teammate targets, pending/ready/pass indicators or timestamps. |
| Dead `Viewer::Seat` | Full vision only after completed death transition; no gameplay commands. This is different from outside spectator. |
| Outside spectator | Public-only; roles revealed on death/end only. No private night action existence, reports, inventory or logs. |
| Dawn/Dusk death announcement | Seat + role; cause and actor hidden. No “killed by Witch/wolf” label. Zero deaths does not certify a save. |
| Ended/public replay | Publicly revealed roles and public history are allowed. Never publish seed, private actions or canonical replay log to outsiders. |
| Audit | Internal only; no gameplay viewer toggle granting Audit knowledge. |

No per-seat private progress, global ready count, “someone acted” toast,
silent placeholder event, pulsing indicator or conditional loading duration
should depend on other players' private actions. Private unauthorized events
must be omitted (`None`), not redacted placeholders. The metadata/cursor/ack
leak and asymmetric voice permission model are unresolved platform questions;
these mock screens cannot certify their resolution. Sources:
[werewolf.md:160–224](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/games/werewolf.md#L160),
[werewolf.md:264–280](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/games/werewolf.md#L264),
[UI contract:27–48,69–94](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/ui/screens/07-werewolf.md#L27).

Bundled public prototype fixtures can be inspected by a reviewer in JavaScript.
DOM concealment tests demonstrate the **review UI's local privacy treatment**,
not production projection security. Production must never ship unauthorized
roles in a client payload and rely on hidden CSS, `aria-hidden`, or local filtering.

Scopes: Night table muted; living wolves speak/listen among wolves; dead channel
for dead seats. Dawn/Dusk table listen-only; Vote table/wolves muted; Day table
for living seats; Ended table for all seats. Chat/voice controls in design are
illustrative and must say unavailable; no mic permission request or fake sent
message implies enforcement. Source: [werewolf.md:244–250](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/games/werewolf.md#L244).

## Known stale illustrative comments

`games/werewolf/src/lib.rs:50–53` says a Doctor can see a `Saved` fact;
`:68–71` mentions possible automatic death on disconnect. Those are older
illustrations, contradicted by the maintained W-D decisions above. Do not use
them to author the UI. The implemented `Event` has no `Saved` variant. No repo
fix is included because this task is an isolated design review.

## Rendering and implementation handoff constraints

Use generated semantic tokens and a reusable review theme/component layer.
Prototype CSS literals are design proposals, not a new production token authority.
Keep marks, icons, board coordinates and focus rings code-native; raster artwork
is decorative/cosmetic, never the hit-test or rule oracle. Text remains live,
readable Vietnamese text with appropriate fallbacks.

DOM review screens may implement setup, roster, card disclosure, modal focus,
action controls and accessible descriptions. The future shipping shell is
Leptos; game canvas/frame/input belongs to the retained Macroquad WASM gameplay
document. A DOM accessibility mirror consumes the same **permitted** facts as
the canvas. Any future DOM/canvas cooperation needs one explicit input owner,
generation/revision validation, cleanup, preference propagation and focus
handoff; the design package is not approval to activate Pixi or an iframe in
production. Sources: [doc04:114–137](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/architecture/04-frontend-and-design-system.md#L114),
[gameplay contract:31–76](https://github.com/loveoverflowcom/tabula/blob/c0a62088c159cc1f20409de41af245c98dcfcfee/docs/ui/screens/gameplay.md#L31).

Required next implementation slices: (1) choose/document a Caro rules variant
and implement/test its module; (2) complete Werewolf headless reducer,
projection/event non-existence/SecretModel coverage; (3) game-owned permitted
view → presenter → RenderList and input-to-intent; (4) actual texture loading,
font/viewport/accessibility and reduced-motion verification; (5) only at their
phases, generic online/session/lobby/replay/chat/voice. None of the mock scenario
JavaScript should become a second rules implementation.

## Evidence ledger

| Claim/check | Kind | Status | Limit |
|---|---|---|---|
| Current source and maintained specs inspected at pinned SHA | source-read | PASS | Exact files/lines above; no rules execution implied |
| Existing prior design source provenance inspected | source-read | PASS | Git tree/SVG at `030da25d0098e240ab2cf36dacf9892e8b320a89`; common Caro/Werewolf/recovery sheet, not runtime pixels |
| Werewolf existing tests identified | source-read | PASS | Config/state/assignment/metadata targets; no reducer/security/presenter tests present |
| Game Rust test execution in this design audit | execution | NOT_RUN | Read-only contract audit; parent may separately report earlier tests, not counted here |
| Caro rules and production gameplay | execution | NOT_IMPLEMENTED | Placeholder only |
| Werewolf actions, resolution, projection security, completed match | execution | NOT_IMPLEMENTED | Creation kernel and structural types cannot establish these claims |
| Independent prototype DOM/keyboard/privacy checks | interaction-tested | PASS | Chrome headless checks below; root's broader headed viewport/scenario checks have their own `verification/` ledger |
| Independent desktop/phone pixel inspection | screenshot-inspected | PASS | Four final Caro playing/Werewolf day images inspected below; early geometry/theme defects were found and their corrections confirmed. Root owns the broader screenshot/viewport ledger |
| Safari/WebKit, physical mobile/AT, network timing/security | runtime | NOT_RUN | Not covered by a Chromium design review; no setting changes authorized |

## Independent prototype review and corrections

The prototypes keep game authority unimplemented and label interactions/results
as simulations. This review found and the design owners corrected:

1. Caro win fixture, board last-move marker and history disagreed; all now use the
   final X at G7 (cell 60).
2. Caro confirmation and Werewolf role/target/vote controls lost keyboard focus
   after DOM replacement; logical focus is restored. Caro grid now has row
   semantics and coordinate indices.
3. Actual early Caro desktop/phone pixels had uneven grid tracks; explicit nine
   rows/columns and stable cell sizing corrected the geometry.
4. Actual early Werewolf pixels resolved light theme aliases on `:root`, leaving
   dark private cards with almost-black text; aliases now resolve on the body
   scope. The inspected old images are not final visual acceptance.
5. Werewolf Dawn announced Nam's death but Day/Vote restored him; the coherent
   sample now retains the public death, nine living players, and disables that
   vote target. A distinct ended fixture reveals its exact ten-seat role multiset.
6. Private Seer Dawn report was missing; deliberate reveal now shows a simulated
   alignment-only report. No report is present while the card is concealed.
7. Werewolf's snapshot/control did not reflect the OS reduced-motion preference;
   the owner synchronized initial state, media changes, manual preference and
   applied styles. OS and manual reduction combine with OR.

Final-source checks are scoped to local design behavior. They exercise fixed
fixtures and DOM/keyboard integration in **headless Chrome 154.0.8037.97** using
the existing Playwright-core 1.62.1 driver, Mac host and loopback server at port
8061. They do not exercise Rust, WASM, networking, timer resolution, an actual
multiplayer match, real assistive technology, window-manager blur or production
projection security. Public-night DOM and clock equality means no local public
feedback changes in the tested mock interactions; it is not a network timing
noninterference proof. Root's headed screenshots and viewport/scenario checks
are independent evidence in `verification/runtime-checks.json`.

The exact independent probe is embedded here so it remains with either light
archive. Run this JavaScript using `node --input-type=module` against the local
design server; the driver/executable paths are the verified Mac environment.

```js
import { createRequire } from 'node:module';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const require=createRequire(import.meta.url);
const {chromium}=require('/Users/manhblue/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright-core');
const root='/Users/manhblue/Documents/Codex/2026-10-03/task-7/design-review-2026-10-03';
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,timeout:10000});
const page=await browser.newPage({viewport:{width:1440,height:1000}});page.setDefaultTimeout(5000);
const checks=[];
function record(name,pass,details={}){checks.push({name,status:pass?'PASS':'FAIL',...details});if(!pass)throw new Error(name);}
try{
 await page.goto('http://127.0.0.1:8061/caro/?scenario=playing');await page.waitForFunction(()=>window.designReview?.game==='caro');
 const geometry=await page.locator('[data-cell]').evaluateAll(cells=>cells.map(c=>{const r=c.getBoundingClientRect();return {row:Number(c.dataset.row),col:Number(c.dataset.col),x:r.x,y:r.y,w:r.width,h:r.height};}));
 const widthRange=Math.max(...geometry.map(c=>c.w))-Math.min(...geometry.map(c=>c.w));
 const heightRange=Math.max(...geometry.map(c=>c.h))-Math.min(...geometry.map(c=>c.h));
 record('Caro 81 uniform cells aligned in 9 tracks',geometry.length===81&&widthRange<.2&&heightRange<.2&&geometry.every(c=>Math.abs(c.x-geometry[c.col].x)<.2&&Math.abs(c.y-geometry[c.row*9].y)<.2),{widthRange,heightRange});
 await page.evaluate(()=>window.designReview.setScenario('win'));
 record('Caro fixture tail agrees with last move',await page.evaluate(()=>window.designReview.snapshot().marks.at(-1).at===Number(document.querySelector('.cell.last').dataset.cell)));
 await page.goto('http://127.0.0.1:8061/werewolf/');await page.waitForFunction(()=>window.designReview?.game==='werewolf');
 const roles=await page.evaluate(()=>window.designReview.roles);let publicBaseline=null;
 for(const role of roles){
  await page.evaluate(role=>{window.designReview.setRole(role);window.designReview.setScenario('night');},role);
  record(role+' concealed role absent from DOM/snapshot',await page.evaluate(()=>!document.querySelector('.role-card')&&!Object.hasOwn(window.designReview.snapshot(),'ownRole')));
  await page.locator('[data-action="reveal-role"]').click();
  const publicBefore=await page.locator('#public-night').innerHTML();const clockBefore=await page.locator('.phase-clock').innerText();
  if(publicBaseline===null)publicBaseline=publicBefore;record(role+' public night invariant',publicBaseline===publicBefore);
  if(role==='Villager')record('Villager no private submit/pass',await page.locator('[data-action="submit-night"],[data-action="pass-night"]').count()===0);
  else{
   const disabled=await page.locator('[data-private-target]:disabled').evaluateAll(bs=>bs.map(b=>Number(b.dataset.privateTarget)));
   record(role+' target guards',JSON.stringify(disabled)===JSON.stringify({Werewolf:[0,3],Seer:[0],Doctor:[5],Hunter:[0],Witch:[]}[role]),{disabled});
   const target=role==='Witch'||role==='Doctor'?0:1;
   await page.locator('[data-private-target="'+target+'"]').focus();await page.keyboard.press('Enter');
   record(role+' keyboard selection retains focus',await page.evaluate(target=>document.activeElement?.dataset.privateTarget===String(target),target));
   await page.locator('[data-action="submit-night"]').click();
   record(role+' private action leaves public panel/clock unchanged',await page.locator('#public-night').innerHTML()===publicBefore&&await page.locator('.phase-clock').innerText()===clockBefore);
   if(role==='Witch')record('Witch one potion mock consumed/night locked',await page.locator('[data-potion="heal"]').innerText().then(t=>t.includes('đã dùng'))&&await page.locator('[data-action="submit-night"],[data-action="pass-night"]').count()===0);
  }
  await page.keyboard.press('Escape');record(role+' Escape removes role and restores reveal focus',await page.evaluate(()=>!document.querySelector('.role-card')&&!Object.hasOwn(window.designReview.snapshot(),'ownRole')&&document.activeElement?.dataset.action==='reveal-role'));
 }
 await page.evaluate(()=>{window.designReview.setRole('Seer');window.designReview.setScenario('dawn');});
 record('Seer report initially concealed',!await page.locator('main').innerText().then(t=>t.includes('Báo cáo riêng mô phỏng')));
 await page.locator('[data-action="reveal-role"]').click();record('Seer authorized Dawn alignment-only report',await page.locator('.private-panel').innerText().then(t=>t.includes('An không thuộc phe Sói')&&t.includes('không vai cụ thể')));
 await page.evaluate(()=>window.designReview.setScenario('reconnect'));record('Reconnect removes private UI/snapshot',await page.evaluate(()=>!document.querySelector('.role-card')&&!document.querySelector('.private-panel')&&!Object.hasOwn(window.designReview.snapshot(),'ownRole')));
 await page.evaluate(()=>window.designReview.setScenario('vote'));record('Vote excludes self/dead seat',await page.locator('[data-target="0"]').isDisabled()&&await page.locator('[data-target="6"]').isDisabled());
 await page.evaluate(()=>window.designReview.setScenario('day'));record('Day preserves public death',await page.locator('.seat.dead').innerText().then(t=>t.includes('Nam')&&t.includes('Dân làng'))&&await page.locator('.panel-heading').innerText().then(t=>t.includes('9 người sống')));
 await page.evaluate(()=>{window.designReview.setRole('Witch');window.designReview.setScenario('night');window.designReview.reveal();});
 const colors=await page.evaluate(()=>({body:getComputedStyle(document.body).backgroundColor,role:getComputedStyle(document.querySelector('.role-content h2')).color,roleBackground:getComputedStyle(document.querySelector('.role-card')).backgroundColor}));
 record('Nocturnal theme body scope',colors.body==='rgb(20, 18, 23)'&&colors.role==='rgb(244, 237, 230)',colors);
 const motionContext=await browser.newContext({reducedMotion:'reduce'});const motion=await motionContext.newPage();motion.setDefaultTimeout(5000);
 await motion.goto('http://127.0.0.1:8061/werewolf/');await motion.waitForFunction(()=>window.designReview?.game==='werewolf');
 record('OS reduction initial snapshot/control/styles',await motion.evaluate(()=>designReview.snapshot().reducedMotion&&document.querySelector('#motion').getAttribute('aria-pressed')==='true'&&document.getAnimations().filter(a=>a.playState==='running').length===0));
 await motion.locator('#motion').click();await motion.locator('#motion').click();record('OS reduction survives manual reduction off',await motion.evaluate(()=>designReview.snapshot().reducedMotion&&document.querySelector('#motion').getAttribute('aria-pressed')==='true'));await motionContext.close();
 const manualContext=await browser.newContext({reducedMotion:'no-preference'});const manual=await manualContext.newPage();manual.setDefaultTimeout(5000);await manual.goto('http://127.0.0.1:8061/werewolf/');await manual.waitForFunction(()=>window.designReview?.game==='werewolf');
 await manual.locator('#motion').click();record('Manual reduction on applied',await manual.evaluate(()=>designReview.snapshot().reducedMotion&&document.body.classList.contains('reduced-motion')&&document.getAnimations().filter(a=>a.playState==='running').length===0));
 await manual.locator('#motion').click();record('Manual reduction off reflected',await manual.evaluate(()=>!designReview.snapshot().reducedMotion&&!document.body.classList.contains('reduced-motion')));await manualContext.close();
 const sourceHashes={};for(const file of ['caro/app.mjs','caro/style.css','werewolf/werewolf.mjs','werewolf/werewolf.css'])sourceHashes[file]=createHash('sha256').update(await readFile(root+'/'+file)).digest('hex');
 console.log(JSON.stringify({status:'PASS',browser:await browser.version(),kind:'actual headless Chrome DOM/keyboard/mock/privacy checks',count:checks.length,sourceHashes,checks},null,2));
}finally{await browser.close();}
```

Final independent run receipt follows after execution. The earlier probes passed
three geometry/privacy groups and 35 role/keyboard assertions; they found no
production correctness evidence because the authority targets are absent.

### Dynamic preference probe: external event delivery limit

Two attempted runs stopped at dynamic preference-change assertions (FAIL):
an immediate assertion, then a bounded 5 s wait. A separate diagnostic added
an independent `matchMedia(...).addEventListener('change', ...)` before invoking
Playwright `page.emulateMedia({reducedMotion:'no-preference'})`. Chrome changed
the query's `matches` value but delivered **zero change events** to either
listener, even after `bringToFront()`, a real screenshot and a 300 ms frame wait:

| Observation | Before | After emulation + screenshot + wait |
|---|---|---|
| `document.visibilityState` | `visible` | `visible` |
| Independent media query `matches` | `true` | `false` |
| Independent media-change event array | `[]` | `[]` |
| Review effective-motion snapshot | `true` | `false` |
| Control `aria-pressed` / body class | `true` / `reduced-motion` | `true` / `reduced-motion` |

Status: **BLOCKED** for dynamic emulated media-change event verification in this
independent headless driver context.
Actual OS preference changes are **NOT_RUN**; no system settings were changed.
The source listener is present, but that is source-read evidence only. The
final passing probe scopes itself to preferences configured **before page
load**, manual changes and their OR behavior. It does not claim dynamic
OS event propagation. The diagnostic confirms an external event-delivery limit;
it does not establish behavior on every browser or actual system setting. Root
observed one passing headed dynamic media-change run, but a repeat failed;
the durable `verification/extra-checks.json` retains that case as **FAIL /
unresolved**, without promoting the earlier observation. Its six-role focus,
setup/room escaping and dispatched DOM blur-handler checks pass. The actual
tab focus-loss concealment case also remains **FAIL / unresolved**. Dispatched
blur, Escape, reconnect and phase-change concealment do not substitute for a
trusted window-manager blur or visibility transition.

### Final independent run receipt

Exact command: `node --input-type=module < /tmp/tabula-design-audit-probe.mjs`
(the script above was extracted verbatim into that temporary file). Exit 0;
47 non-empty assertions PASS. No prototype source changes during this run.

```json
{
  "status": "PASS",
  "browser": "154.0.8037.97",
  "kind": "actual headless Chrome DOM/keyboard/mock/privacy checks",
  "count": 47,
  "sourceHashes": {
    "caro/app.mjs": "28386c20c8790f8939f31d5bb75e7ac09eac00a58db5e8739b0e789fc560c914",
    "caro/style.css": "c82e52f1625a839536b3879c56204c8f279e17a8818e41304dd7377d6d761035",
    "werewolf/werewolf.mjs": "bd8d9358ffa077a592b0de889481aa7eaf8c6fe55b19d4df7b1279d91af11a46",
    "werewolf/werewolf.css": "ccbe06a4e7f933baea772a43eb4a651995711ec3719ff537a3a23c4d69832e2c"
  },
  "checks": [
    {
      "name": "Caro 81 uniform cells aligned in 9 tracks",
      "status": "PASS",
      "widthRange": 0.015625,
      "heightRange": 0.015625
    },
    {
      "name": "Caro fixture tail agrees with last move",
      "status": "PASS"
    },
    {
      "name": "Villager concealed role absent from DOM/snapshot",
      "status": "PASS"
    },
    {
      "name": "Villager public night invariant",
      "status": "PASS"
    },
    {
      "name": "Villager no private submit/pass",
      "status": "PASS"
    },
    {
      "name": "Villager Escape removes role and restores reveal focus",
      "status": "PASS"
    },
    {
      "name": "Werewolf concealed role absent from DOM/snapshot",
      "status": "PASS"
    },
    {
      "name": "Werewolf public night invariant",
      "status": "PASS"
    },
    {
      "name": "Werewolf target guards",
      "status": "PASS",
      "disabled": [
        0,
        3
      ]
    },
    {
      "name": "Werewolf keyboard selection retains focus",
      "status": "PASS"
    },
    {
      "name": "Werewolf private action leaves public panel/clock unchanged",
      "status": "PASS"
    },
    {
      "name": "Werewolf Escape removes role and restores reveal focus",
      "status": "PASS"
    },
    {
      "name": "Seer concealed role absent from DOM/snapshot",
      "status": "PASS"
    },
    {
      "name": "Seer public night invariant",
      "status": "PASS"
    },
    {
      "name": "Seer target guards",
      "status": "PASS",
      "disabled": [
        0
      ]
    },
    {
      "name": "Seer keyboard selection retains focus",
      "status": "PASS"
    },
    {
      "name": "Seer private action leaves public panel/clock unchanged",
      "status": "PASS"
    },
    {
      "name": "Seer Escape removes role and restores reveal focus",
      "status": "PASS"
    },
    {
      "name": "Doctor concealed role absent from DOM/snapshot",
      "status": "PASS"
    },
    {
      "name": "Doctor public night invariant",
      "status": "PASS"
    },
    {
      "name": "Doctor target guards",
      "status": "PASS",
      "disabled": [
        5
      ]
    },
    {
      "name": "Doctor keyboard selection retains focus",
      "status": "PASS"
    },
    {
      "name": "Doctor private action leaves public panel/clock unchanged",
      "status": "PASS"
    },
    {
      "name": "Doctor Escape removes role and restores reveal focus",
      "status": "PASS"
    },
    {
      "name": "Hunter concealed role absent from DOM/snapshot",
      "status": "PASS"
    },
    {
      "name": "Hunter public night invariant",
      "status": "PASS"
    },
    {
      "name": "Hunter target guards",
      "status": "PASS",
      "disabled": [
        0
      ]
    },
    {
      "name": "Hunter keyboard selection retains focus",
      "status": "PASS"
    },
    {
      "name": "Hunter private action leaves public panel/clock unchanged",
      "status": "PASS"
    },
    {
      "name": "Hunter Escape removes role and restores reveal focus",
      "status": "PASS"
    },
    {
      "name": "Witch concealed role absent from DOM/snapshot",
      "status": "PASS"
    },
    {
      "name": "Witch public night invariant",
      "status": "PASS"
    },
    {
      "name": "Witch target guards",
      "status": "PASS",
      "disabled": []
    },
    {
      "name": "Witch keyboard selection retains focus",
      "status": "PASS"
    },
    {
      "name": "Witch private action leaves public panel/clock unchanged",
      "status": "PASS"
    },
    {
      "name": "Witch one potion mock consumed/night locked",
      "status": "PASS"
    },
    {
      "name": "Witch Escape removes role and restores reveal focus",
      "status": "PASS"
    },
    {
      "name": "Seer report initially concealed",
      "status": "PASS"
    },
    {
      "name": "Seer authorized Dawn alignment-only report",
      "status": "PASS"
    },
    {
      "name": "Reconnect removes private UI/snapshot",
      "status": "PASS"
    },
    {
      "name": "Vote excludes self/dead seat",
      "status": "PASS"
    },
    {
      "name": "Day preserves public death",
      "status": "PASS"
    },
    {
      "name": "Nocturnal theme body scope",
      "status": "PASS",
      "body": "rgb(20, 18, 23)",
      "role": "rgb(244, 237, 230)",
      "roleBackground": "rgb(40, 42, 65)"
    },
    {
      "name": "OS reduction initial snapshot/control/styles",
      "status": "PASS"
    },
    {
      "name": "OS reduction survives manual reduction off",
      "status": "PASS"
    },
    {
      "name": "Manual reduction on applied",
      "status": "PASS"
    },
    {
      "name": "Manual reduction off reflected",
      "status": "PASS"
    }
  ]
}
```

### Final independent pixel inspection

The four recaptured images below were inspected after the board sizing,
Werewolf theme alias and coherent Day fixture corrections. These are local
prototype pixels; they do not demonstrate an implemented game module.

| Final image | Observed result | Status |
|---|---|---|
| [Caro desktop playing](previews/caro-desktop-playing.png) | Uniform square nine-by-nine board; X/O marks aligned; turn, last-move history and simulated review labels readable | PASS |
| [Caro phone playing](previews/caro-phone-playing.png) | Same aligned board uses intentional internal horizontal scroll; turn/history/action controls remain readable in the vertical page | PASS |
| [Werewolf desktop day](previews/werewolf-desktop-day.png) | Dark body/private card and light text resolve correctly; nine living seats and Nam's public death agree; role card initially concealed | PASS |
| [Werewolf phone day](previews/werewolf-phone-day.png) | Readable wrapped roster retains dead Nam; private card initially concealed; action and review footer reachable through vertical scroll | PASS |

Only these four final images are independently pixel-inspected in this audit.
Root's larger capture set and actual headed interactions have separate
receipts. Physical phones, Safari/WebKit, VoiceOver, complete contrast-pair
measurement and actual OS preference changes remain **NOT_RUN** here.
