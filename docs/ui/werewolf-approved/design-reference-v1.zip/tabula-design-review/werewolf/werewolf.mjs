import {cardFront,cardBack} from '../deck/cards.mjs';
import {discoveryMarkup,applySurface} from '../shared/shell.mjs';
/** Isolated design-review presentation. No rules reducer, transport or canonical game state. */
const $ = (s) => document.querySelector(s);
const main = $('#main');
const icons = {
 moon:'<path d="M20 15.5A8.5 8.5 0 0 1 8.5 4a8.5 8.5 0 1 0 11.5 11.5Z"/>',
 sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>',
 lock:'<rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15" r="1"/>',
 shield:'<path d="m12 3 8 3v6c0 5-8 9-8 9S4 17 4 12V6Z"/><path d="m8 12 3 3 5-6"/>',
 users:'<circle cx="9" cy="8" r="3"/><path d="M3 20v-3a6 6 0 0 1 12 0v3m2-15a3 3 0 0 1 0 6m1 3a5 5 0 0 1 3 4v2"/>',
 arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>',
 eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
 eyeoff:'<path d="m3 3 18 18M8 5.6a12 12 0 0 1 4-.6c6 0 10 7 10 7a21 21 0 0 1-3 3.8M6.4 6.4A22 22 0 0 0 2 12s4 7 10 7a12 12 0 0 0 5-1.1"/>',
 check:'<path d="m5 12 4 4L19 6"/>',
 chat:'<path d="M20 16a3 3 0 0 1-3 3H9l-5 3V7a3 3 0 0 1 3-3h10a3 3 0 0 1 3 3Z"/><path d="M8 9h8m-8 4h5"/>',
 wolf:'<path d="m5 11-2-8 7 4h4l7-4-2 8v5l-7 6-7-6Z"/><path d="m7 12 3 1m7-1-3 1m-4 4h4m-2-3v3"/>',
 doctor:'<path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6Z"/>',
 hunter:'<circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 1v5m0 12v5M1 12h5m12 0h5"/>',
 witch:'<path d="M8 3h8m-6 0v6l-6 9a2 2 0 0 0 2 3h12a2 2 0 0 0 2-3l-6-9V3M7 15h10"/><circle cx="11" cy="17" r=".7"/>',
 villager:'<path d="m3 11 9-8 9 8M5 9v12h14V9m-9 12v-7h4v7"/>',
 vote:'<path d="m8 3 10 4-4 9-10-4Z"/><path d="M3 14v7h18v-7m-13 3h8"/>',
 reconnect:'<path d="M20 7a9 9 0 0 0-15-3L2 7m0-5v5h5m-3 10a9 9 0 0 0 15 3l3-3m0 5v-5h-5"/>',
 warning:'<path d="m12 3 10 18H2Z"/><path d="M12 8v6m0 3v1"/>',
 play:'<path d="m8 4 12 8-12 8Z"/>',
 book:'<path d="M12 6s-5-4-10-2v15c5-2 10 2 10 2s5-4 10-2V4c-5-2-10 2-10 2Zm0 0v15"/>',
 volumeoff:'<path d="m11 4-5 5H2v6h4l5 5Zm5 5 6 6m0-6-6 6"/>',
 history:'<path d="M3 10a9 9 0 1 1 2 8M3 4v6h6m3-4v6l4 2"/>',
 star:'<path d="m12 2 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z"/>',
 copy:'<rect x="8" y="8" width="13" height="13" rx="3"/><path d="M16 8V3H3v13h5"/>',
 leaf:'<path d="M20 3C8 2 3 7 4 14c1 8 12 9 16-11Z"/><path d="M4 20 16 8"/>'
};
const icon = (name, extra='') => `<svg viewBox="0 0 24 24" class="icon ${extra}" aria-hidden="true">${icons[name] || icons.moon}</svg>`;
const safe = (v) => String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const hero = (cls='') => `<img src="../assets/werewolf-hero.webp" class="${cls}" alt="Minh họa gốc: ngôi làng nhỏ dưới ánh trăng, rừng xanh tím và cửa sổ ấm" width="1536" height="1024">`;
const roleData = Object.freeze({
 Villager:{name:'Dân làng',icon:'villager',team:'Phe Dân làng',description:'Không có năng lực riêng trong đêm. Quan sát, lắng nghe và dùng lá phiếu ban ngày để tìm ra Sói.',action:'Đợi bình minh',hint:'Bạn không có hành động riêng trong đêm. Không có nút gửi hoặc bỏ qua.'},
 Werewolf:{name:'Ma sói',icon:'wolf',team:'Phe Ma sói',description:'Bạn biết đồng đội Sói. Mỗi đêm, chọn một người còn sống ngoài phe Sói hoặc bỏ qua.',action:'Chọn mục tiêu',hint:'Lựa chọn của đồng đội được giữ kín. Nếu các lựa chọn hòa nhau, không có cuộc tấn công.'},
 Seer:{name:'Tiên tri',icon:'eye',team:'Phe Dân làng',description:'Mỗi đêm, soi một người khác còn sống. Báo cáo riêng ở bình minh cho biết phe Sói hay không thuộc phe Sói.',action:'Soi một người',hint:'Kết quả đến ở bình minh, không hiển thị vai trò cụ thể của mục tiêu.'},
 Doctor:{name:'Bác sĩ',icon:'doctor',team:'Phe Dân làng',description:'Bảo vệ một người trước cuộc tấn công của Sói. Có thể tự bảo vệ, nhưng không lặp lại cùng mục tiêu hai đêm liên tiếp.',action:'Chọn người bảo vệ',hint:'Linh là mục tiêu đêm trước trong kịch bản này. Không thể chọn lại. Bảo vệ không chặn độc.'},
 Hunter:{name:'Thợ săn',icon:'hunter',team:'Phe Dân làng',description:'Đánh dấu trước một người khác còn sống trong đêm. Dấu giữ đến hết vòng bỏ phiếu và chỉ kích hoạt một lần nếu bạn chết.',action:'Đánh dấu trước',hint:'Đánh dấu khi còn sống. Không có hành động bắn sau khi chết hoặc sau khi thấy mọi vai.'},
 Witch:{name:'Phù thủy',icon:'witch',team:'Phe Dân làng',description:'Có một bình cứu và một bình độc cho cả ván. Mỗi đêm dùng tối đa một bình hoặc bỏ qua; có thể chọn chính mình.',action:'Chọn một bình',hint:'Cứu mù: không được biết ai bị Sói nhắm. Bình được dùng ngay khi gửi, dù không có hiệu quả.'}
});
const roleKeys = Object.keys(roleData);
const names = ['Minh','An','Hà','Khoa','Vy','Linh','Nam','Mai','Quân','Tú','Huy','Ngọc','Bảo','Trang','Duy','Thu','Long','Lan','Phúc','Yến'];
// Review-only public roster. No role field is carried here.
const publicRoster = names.map((name,id)=>Object.freeze({id,name,initial:name[0],you:id===0}));
const state = {scenario:'entry', ownRole:'Witch', revealed:false, target:null, ballot:null, voteMode:'plurality', potion:'heal', submitted:false, charges:{heal:true,poison:true}, seats:10, roomName:'Làng dưới trăng', reconnectError:false, replayStep:0, reduced:false};
const reducedMotionQuery=window.matchMedia('(prefers-reduced-motion: reduce)');
const effectiveReducedMotion=()=>state.reduced||reducedMotionQuery.matches;
function syncMotionPreference(){const effective=effectiveReducedMotion();document.body.classList.toggle('reduced-motion',effective);$('#motion').setAttribute('aria-pressed',String(effective));$('#motion').title=reducedMotionQuery.matches?'Hệ thống đang yêu cầu giảm chuyển động.':'Bật hoặc tắt tùy chọn giảm chuyển động của bản review.';}
reducedMotionQuery.addEventListener('change',syncMotionPreference);
const scenarios = ['entry','setup','lobby','reveal','day','vote','night','dawn','result','replay','reconnect'];
function announce(message){$('#announce').textContent=message;}
function button(label,action,style='primary',ico='arrow',more=''){return `<button class="${style}" data-action="${action}" ${more}>${icon(ico)}${label}</button>`;}
const futureNote = (text='Tương tác mô phỏng. Chat, giọng nói và phiên trực tuyến chưa được triển khai.') => `<p class="future-note">${icon('lock')}<span>${text}</span></p>`;
const title = (name,desc,tag='ClassicV1') => `<div class="screen-title"><div><p class="eyebrow">MA SÓI · TABULA</p><h1>${name}</h1><p>${desc}</p></div><span class="pill purple">${tag}</span></div>`;
function roster({dead=false,targets=false,votes=false,result=false}={}){
 return `<div class="roster" aria-label="Danh sách công khai">${publicRoster.slice(0,state.scenario==='lobby'?state.seats:10).map(seat=>{
 const isDead=dead&&seat.id===6; const selected=targets&&state.target===seat.id; const count=votes?([0,1,1,0,0,2,0,0,1,0][seat.id]+(state.ballot===seat.id?1:0)):0;
 const roleRevealed=isDead?'Dân làng':null;
 const tag=targets?'button':'div';
 return `<${tag} class="seat ${seat.you?'you':''} ${isDead?'dead':''} ${selected?'selected':''}" ${targets?`data-target="${seat.id}" aria-pressed="${selected}" ${seat.you||isDead?'disabled':''}`:''}><span class="seat-number">${seat.id+1}</span><span class="avatar">${seat.initial}</span><strong>${safe(seat.name)}${seat.you?' · Bạn':''}</strong><small>${roleRevealed?'Đã chết · '+roleRevealed:seat.you?'Ghế của bạn':targets?'Chọn để bỏ phiếu':'Còn sống'}</small>${votes&&count?`<span class="vote-dot" aria-label="${count} phiếu">${count}</span>`:''}</${tag}>`;
 }).join('')}</div>`;
}
function entry(){return discoveryMarkup('werewolf');}
function setup(){
 const n=state.seats; const wolves=n===20?5:n>=16?4:n>=12?3:n>=8?2:1; const hunter=n>=8?1:0; const witch=n>=10?1:0; const counts={Werewolf:wolves,Seer:1,Doctor:1,Hunter:hunter,Witch:witch,Villager:n-wolves-2-hunter-witch};
 return title('Một bàn chơi, nhiều bí mật.','Chọn quy mô và nhịp chơi cho bản mô phỏng.')+`<section class="setup-grid"><div class="section-card"><h2>Thiết lập bàn</h2><p>Không tạo phòng thật hoặc gửi dữ liệu.</p><div class="field"><label for="room-name">Tên bàn</label><input id="room-name" maxlength="40" value="${safe(state.roomName)}" autocomplete="off"><small>Tên chỉ dùng để minh họa giao diện.</small></div><div class="field"><label for="seat-count">Số người</label><select id="seat-count">${Array.from({length:15},(_,i)=>i+6).map(n=>`<option value="${n}" ${n===state.seats?'selected':''}>${n} người</option>`).join('')}</select></div><div class="field"><label>Luật bỏ phiếu</label><div class="segmented" role="group" aria-label="Luật bỏ phiếu"><button data-mode="plurality" aria-pressed="${state.voteMode==='plurality'}">Nhiều phiếu nhất</button><button data-mode="majority" aria-pressed="${state.voteMode==='majority'}">Đa số tuyệt đối</button></div><small>${state.voteMode==='plurality'?'Một người có số phiếu dương cao nhất duy nhất bị loại.':'Cần hơn một nửa tổng số người còn sống.'} Nếu hòa mức cao nhất, không ai bị loại.</small></div><div class="settings-line"><span>Cửa sổ thảo luận</span><strong>120 giây</strong></div><div class="settings-line"><span>Cửa sổ đêm / bỏ phiếu</span><strong>30 / 30 giây</strong></div><div class="settings-line"><span>Bình minh / hoàng hôn</span><strong>2 / 2 giây</strong></div>${button('Xem phòng chờ','lobby')}${futureNote('Các thời lượng là mặc định từ luật. Không có bộ đếm hoặc máy chủ trong bản review.')}</div><div class="section-card"><h2>Bộ vai ClassicV1</h2><p>Phân bố công khai theo ${n} người. Vai cụ thể của từng ghế được giữ kín.</p><div class="role-counts">${Object.entries(counts).map(([key,count])=>`<div class="role-count">${icon(roleData[key].icon)}<span>${roleData[key].name}</span><strong>${count}</strong></div>`).join('')}</div><div class="note-box">${icon('shield')}<span>Chỉ sáu vai cơ bản. Không tùy biến số lượng vai hoặc thêm vai nâng cao.</span></div><p class="fine-note">6–20 ghế · Không thay người giữa ván · Mất kết nối không tự động loại một ghế.</p></div></section>`;
}
function lobby(){return title(safe(state.roomName||'Làng dưới trăng'),'Phòng chờ mô phỏng · Chưa có máy chủ hoặc người chơi thật.')+`<div class="room-strip"><div><p>MÃ PHÒNG MẪU</p><div class="room-code">TRANG10</div></div>${button('Sao chép mã mẫu','copy','tonal','copy')}</div><div class="lobby-grid"><section class="section-card"><div class="panel-heading"><h2>Những gương mặt của làng</h2><span>${state.seats} ghế mẫu</span></div>${roster()}<p class="phase-hint">Các ghế là dữ liệu thiết kế. Không có trạng thái sẵn sàng hoặc quyền bắt đầu trận thật.</p></section><aside class="section-card"><h2>Trước khi trăng lên</h2><ul class="rule-list"><li>${icon('lock')}Vai chỉ xuất hiện ở khu vực riêng sau thao tác xem.</li><li>${icon('users')}Suy luận từ sự kiện và phiếu công khai.</li><li>${icon('moon')}Đêm có thời lượng cố định, không kết thúc sớm.</li><li>${icon('volumeoff')}Luồng tiếng nói và chat là khả năng tương lai.</li></ul>${button('Xem nhận vai','reveal')}${button('Đổi thiết lập','setup','quiet','arrow')}</aside></div>`;}
function privateCard({allowAction=false}={}){
 if(!state.revealed)return `<aside class="private-panel" aria-label="Khu vực riêng"><p class="private-label">${icon('lock')}CHỈ MÌNH BẠN</p>${cardBack()}${button('Xem lá bài của tôi','reveal-role','primary','eye')}<p class="privacy-foot">Mặt sau chung không có thông tin vai. Chỉ tạo mặt trước sau thao tác xem. Đổi màn hình hoặc kết nối lại sẽ che thẻ.</p></aside>`;
 const role=roleData[state.ownRole];
 return `<aside class="private-panel" aria-label="Khu vực riêng"><p class="private-label">${icon('lock')}CHỈ MÌNH BẠN · VAI MÔ PHỎNG</p>${cardFront(state.ownRole)}${state.ownRole==='Werewolf'?'<p class="privacy-foot">Kiến thức riêng mô phỏng: Khoa là đồng đội Sói. Không thấy mục tiêu hoặc trạng thái hành động của Khoa.</p>':''}${state.scenario==='dawn'&&state.ownRole==='Seer'?'<div class="local-status">Báo cáo riêng mô phỏng: An không thuộc phe Sói.</div><p class="privacy-foot">Chỉ báo phe, không vai cụ thể. Báo cáo vẫn được nhận nếu Tiên tri hoặc mục tiêu chết trong lần phân giải này.</p>':''}${allowAction?nightAction():`<p class="privacy-foot">Đừng chia sẻ thẻ này. Năng lực được dùng khi đúng pha và theo quyền xem hợp lệ trong game thật.</p>`}<div class="private-actions">${button('Che lá bài','conceal-role','tonal','eyeoff')}${button('Vai kế · review','next-role','quiet','arrow')}</div></aside>`;
}
function revealScreen(){return `<section class="reveal-layout"><div class="reveal-copy"><p class="eyebrow">KHOẢNH KHẮC RIÊNG CỦA BẠN</p><h1>Một chiếc thẻ.<br>Một góc nhìn<br><em>hoàn toàn khác.</em></h1><p>Bạn là một phần của câu chuyện.<br>Xem lá bài khi sẵn sàng — rồi cất bí mật ấy đi.</p><div class="feature"><div class="feature-icon">${icon('eyeoff')}</div><div><strong>Xem chủ động, che tức thì</strong><small>Không có lật thẻ tự động hay đếm ngược.</small></div></div><div class="actions">${button('Xem bàn ban đêm','night','tonal','moon')}${button('Đến ban ngày','day','quiet','sun')}</div></div>${privateCard()}</section>`;}
const phaseNames=['Đêm','Bình minh','Thảo luận','Bỏ phiếu','Hoàng hôn'];
function matchHeader(phase){
 const phaseIdx={night:0,dawn:1,day:2,vote:3}[phase]; const copy={night:['Đêm thứ hai','moon','Cả làng giữ yên lặng.','30 giây'],dawn:['Bình minh','sun','Chỉ sự kiện công khai được thông báo.','2 giây'],day:['Cùng nhau suy luận','chat','Ban ngày · Vòng 2 · 9 người sống','120 giây'],vote:['Lá phiếu của bạn','vote','Bỏ phiếu · Vòng 2 · Không tự kết thúc sớm','30 giây']}[phase];
 return `<div class="match-header"><div class="phase-heading"><span class="phase-symbol">${icon(copy[1])}</span><div><h1>${copy[0]}</h1><p>${copy[2]}</p></div></div><div class="phase-clock"><strong>${copy[3]}</strong><small>Cửa sổ mô phỏng cố định</small></div></div><div class="phase-track" aria-label="Các pha của vòng">${phaseNames.map((n,i)=>`<span class="${i===phaseIdx?'active':''}" ${i===phaseIdx?'aria-current="step"':''}>${n}</span>`).join('')}</div>`;
}
function day(){return matchHeader('day')+`<div class="match-grid"><section class="section-card public-panel"><div class="panel-heading"><h2>Quanh bàn của làng</h2><span>Công khai · 9 người sống</span></div>${roster({dead:true})}<div class="discussion"><div class="discussion-title">${icon('chat')}THẢO LUẬN · NỘI DUNG MẪU</div><p class="quote"><strong>Hà</strong>Nam đã rời làng và được công khai là Dân làng. Mình muốn nghe mọi người nói trước khi quyết định.</p><p class="quote"><strong>Linh</strong>Hãy nhìn lại lá phiếu hôm trước. Mình đang chú ý những người đổi ý vào phút cuối.</p><p class="quote"><strong>Minh · Bạn</strong>Chưa có đủ thông tin. Mình sẽ lắng nghe thêm.</p><div class="quiet-input">${icon('lock')}Gửi tin và giọng nói chưa được triển khai.</div></div><p class="phase-hint">Vai của Nam đã công khai. Nguyên nhân chết và người thực hiện vẫn không được công bố.</p></section>${privateCard()}</div><div class="actions" style="margin-top:20px">${button('Review pha bỏ phiếu','vote','tonal','vote')}${button('Review pha đêm','night','quiet','moon')}</div>`;}
function vote(){return matchHeader('vote')+`<div class="match-grid"><section class="section-card public-panel"><div class="panel-heading"><h2>Bạn muốn bỏ phiếu cho ai?</h2><span>Lá phiếu công khai</span></div>${roster({dead:true,targets:true,votes:true})}<div class="vote-panel"><h3>${state.target!==null?'Mục tiêu đang chọn: '+names[state.target]:'Chọn một người còn sống khác bạn'}</h3><p>Phiếu được thay đổi hoặc rút trước hạn. Hòa mức phiếu cao nhất sẽ không loại ai.</p><div class="actions">${button('Gửi phiếu mô phỏng','cast-vote','primary','vote',state.target===null?'disabled':'')}${button('Trắng phiếu','abstain','tonal','vote')}${button('Rút phiếu','unvote','quiet','history')}</div><div class="vote-meta"><span>${state.ballot===null?'Chưa có phiếu của bạn':state.ballot==='abstain'?'Bạn đang trắng phiếu':'Phiếu của bạn: '+names[state.ballot]}</span><span>Mốc đóng pha giữ nguyên</span></div></div><p class="phase-hint">Các phiếu mẫu không mở rộng kiến thức về vai. Không bỏ phiếu cho chính mình.</p></section>${privateCard()}</div>`;}
function nightAction(){
 const key=state.ownRole, role=roleData[key];
 if(key==='Villager')return `<div class="action-box"><h3>Đợi bình minh</h3><p>${role.hint}</p><div class="local-status">Bạn chỉ quan sát pha công khai.</div></div>`;
 const exclude=[...(key==='Werewolf'?[0,3]:[]),...(key==='Hunter'||key==='Seer'?[0]:[]),...(key==='Doctor'?[5]:[])];
 const potionSelect=key==='Witch'?`<div class="segmented" role="group" aria-label="Chọn một bình"><button data-potion="heal" aria-pressed="${state.potion==='heal'}" ${!state.charges.heal||state.submitted?'disabled':''}>Cứu · ${state.charges.heal?'1 bình':'đã dùng'}</button><button data-potion="poison" aria-pressed="${state.potion==='poison'}" ${!state.charges.poison||state.submitted?'disabled':''}>Độc · ${state.charges.poison?'1 bình':'đã dùng'}</button></div>`:'';
 return `<div class="action-box"><h3>${role.action}</h3><p>${role.hint}</p>${potionSelect}<div class="target-list" aria-label="Mục tiêu riêng">${publicRoster.slice(0,10).map(seat=>`<button class="target" data-private-target="${seat.id}" aria-pressed="${state.target===seat.id}" ${exclude.includes(seat.id)||state.submitted?'disabled':''}>${seat.name}${seat.you?' · Bạn':''}</button>`).join('')}</div>${state.submitted?'<div class="local-status">Lựa chọn mô phỏng đã ghi nhận riêng. Không gửi mạng.</div>':`${button(key==='Witch'?(state.potion==='heal'?'Dùng bình cứu mô phỏng':'Dùng bình độc mô phỏng'):'Gửi lựa chọn mô phỏng','submit-night','primary',role.icon,state.target===null?'disabled':'')}${button('Bỏ qua mô phỏng','pass-night','quiet','moon')}`}<p class="fine-note">Không tiết lộ lựa chọn hoặc tiến độ của người khác.</p></div>`;
}
function night(){return matchHeader('night')+`<div class="match-grid"><section class="section-card public-panel" id="public-night"><div class="panel-heading"><h2>Làng đang nghỉ</h2><span>Công khai · 10 người sống</span></div>${roster()}<div class="waiting-public">${icon('moon')}<div><h3>Một khoảng lặng dưới trăng</h3><p>Chờ pha đêm kết thúc ở mốc đã định.</p></div></div><p class="phase-hint">Không có trạng thái hành động, dấu đã xong hoặc số người đang chờ. Không biết ai đã dùng năng lực.</p><div class="discussion"><div class="discussion-title">${icon('volumeoff')}KHÔNG GIAN CÔNG KHAI</div><p class="quote">Bàn tắt trao đổi trong đêm. Trao đổi riêng của Sói và người đã chết cần phiên trực tuyến hợp lệ.</p></div></section>${privateCard({allowAction:true})}</div>`;}
function dawn(){return matchHeader('dawn')+`<section class="dawn-banner">${icon('sun')}<div><h2>Ánh sáng trở về ngôi làng.</h2><p>Nam đã rời cuộc chơi. Vai Dân làng được công khai ở bình minh. Không công bố nguyên nhân chết hoặc người thực hiện.</p></div></section><div class="match-grid"><section class="section-card public-panel"><div class="panel-heading"><h2>Tình hình công khai</h2><span>9 người sống · 1 đã chết</span></div>${roster({dead:true})}<div class="dawn-event"><span class="avatar">N</span><div><strong>Nam · Dân làng</strong><p>Đã chết trong lần chuyển pha hoàn tất.</p></div></div><p class="phase-hint">Đây là sự kiện mẫu, không phải kết quả suy ra từ các hành động bạn đã bấm.</p></section>${privateCard()}</div><div class="actions" style="margin-top:20px">${button('Review thảo luận','day','tonal','chat')}</div>`;}
// A distinct, explicitly ended public fixture. These role facts never render in a live scenario.
const endedRoles=['Witch','Villager','Seer','Werewolf','Villager','Doctor','Villager','Werewolf','Hunter','Villager'];
function publicEndRoster(){return `<div class="result-roles">${publicRoster.slice(0,10).map((seat,i)=>`<div class="result-role"><span class="avatar">${seat.initial}</span><div><strong>${seat.name}${seat.you?' · Bạn':''}</strong><span>${roleData[endedRoles[i]].name}${[3,6,7].includes(i)?' · Đã chết':' · Còn sống'}</span></div>${icon(roleData[endedRoles[i]].icon)}</div>`).join('')}</div>`;}
function result(){return `<div class="result-layout"><section><div class="result-art">${hero()}<div><span class="pill amber">KẾT QUẢ MÔ PHỎNG</span><h1>Ngôi làng<br>đón bình yên.</h1><p>Phe Dân làng thắng · Mọi vai được công khai khi ván kết thúc.</p></div></div><div class="actions">${button('Xem lại câu chuyện','replay','primary','history')}${button('Về phòng chờ','lobby','tonal','users')}</div><p class="fine-note">Kết quả cố định để review. Không tính chiến thắng từ thao tác trong bản thiết kế.</p></section><section class="section-card"><p class="eyebrow">ĐẾN LÚC MỞ NHỮNG BÍ MẬT</p><h2>Những vai trong câu chuyện</h2><p>Chỉ kịch bản kết thúc được phép hiển thị tất cả vai công khai.</p><div class="result-stat"><div><strong>4</strong><span>vòng mẫu</span></div><div><strong>10</strong><span>ghế mẫu</span></div><div><strong>6</strong><span>vai cơ bản</span></div></div>${publicEndRoster()}${futureNote('Không công khai seed hoặc nhật ký hành động riêng. Replay thật còn phụ thuộc hợp đồng và phase gate.')}</section></div>`;}
const replayEvents=[{round:'VÒNG 1',title:'Bình minh yên tĩnh',desc:'Không công bố người chết. Không suy ra lần cứu.',icon:'sun'},{round:'VÒNG 2',title:'Nam · Dân làng rời cuộc chơi',desc:'Chỉ vai đã công khai, không nguyên nhân hoặc actor.',icon:'sun'},{round:'VÒNG 3',title:'Phiếu hòa, không ai bị loại',desc:'Kịch bản công khai tại hoàng hôn.',icon:'vote'},{round:'VÒNG 4',title:'Phe Dân làng thắng',desc:'Mọi vai được công khai sau khi kết thúc.',icon:'star'}];
function replay(){const event=replayEvents[state.replayStep];return title('Nhìn lại câu chuyện','Timeline công khai mô phỏng · Không phải replay từ log game.')+`<div class="setup-grid"><section class="section-card"><h2>Những mốc của ngôi làng</h2><div class="timeline">${replayEvents.map((event,i)=>`<button data-replay-step="${i}" aria-pressed="${state.replayStep===i}"><span class="timeline-round">${event.round}</span><div><strong>${event.title}</strong><small>${event.desc}</small></div></button>`).join('')}</div><p class="fine-note">Timeline không chứa số lượng, thời điểm hoặc nội dung của hành động ban đêm. Scrub thật là khả năng tương lai.</p></section><section class="section-card"><span class="pill amber">${event.round}</span><h2 style="margin-top:16px">${event.title}</h2><p>${event.desc}</p>${state.replayStep===3?publicEndRoster():`<div class="note-box">${icon('lock')}<span>Chỉ thông tin đã công khai đến mốc này. Mọi vai còn kín vắng khỏi nội dung và cây trợ năng.</span></div>`}<div class="actions" style="margin-top:22px">${button('Mốc tiếp theo','next-replay','tonal','arrow')}${button('Kết quả','result','quiet','star')}</div></section></div>`;}
function reconnect(){return `<section class="reconnect-panel"><div class="reconnect-symbol">${icon(state.reconnectError?'warning':'reconnect')}</div><p class="eyebrow">PHIÊN MÔ PHỎNG</p><h1>${state.reconnectError?'Chưa thể trở lại bàn.':'Tạm ngắt kết nối.<br>Bí mật vẫn được che.'}</h1><p class="${state.reconnectError?'error-state':''}">${state.reconnectError?'Lần thử mô phỏng không thành công. Bạn có thể thử lại hoặc về phòng chờ. Không phục hồi nội dung riêng từ bản cũ.':'Lá bài riêng đã được gỡ khỏi màn hình. Trong game thật, pha tiếp tục chạy; ghế vẫn còn sống và không có người thay thế.'}</p><div class="actions">${button(state.reconnectError?'Thử lại mô phỏng':'Review lỗi kết nối','retry','primary','reconnect')}${button('Về phòng chờ','lobby','tonal','users')}</div><div class="note-box">${icon('lock')}<span>Chỉ mở lại phần riêng khi thông tin mới đã được xác nhận cho đúng người chơi. Thiếu lựa chọn sẽ mặc định bỏ qua hoặc trắng phiếu khi hết hạn; không tự động chết.</span></div><p class="fine-note">Không có WebSocket hoặc xác thực phiên trong bản review.</p></section>`;}
const renderers={entry,setup,lobby,reveal:revealScreen,day,vote,night,dawn,result,replay,reconnect};
function render(){
 const active=document.activeElement;
 let identity=null;
 if(main.contains(active)){
  if(active.id)identity='#'+CSS.escape(active.id);
  else for(const key of ['action','target','privateTarget','mode','potion','replayStep'])if(active.dataset[key]!==undefined){const attr=key.replace(/[A-Z]/g,c=>'-'+c.toLowerCase());identity='[data-'+attr+'="'+CSS.escape(active.dataset[key])+'"]';break;}
 }
 main.innerHTML=renderers[state.scenario]();$('#scenario').value=state.scenario;document.body.dataset.scenario=state.scenario;applySurface('werewolf',state.scenario);
 if(identity){const restored=main.querySelector(identity)||main.querySelector('[data-action="'+(state.revealed?'conceal-role':'reveal-role')+'"]')||main;restored.focus({preventScroll:true});}
}
function conceal({rerender=true}={}){state.revealed=false;state.target=null;if(rerender)render();}
function setScenario(value){if(!scenarios.includes(value))throw new RangeError('Unknown review scenario');conceal({rerender:false});state.scenario=value;if(!['entry','setup','lobby'].includes(value))state.seats=10;state.submitted=false;state.charges={heal:true,poison:true};state.reconnectError=false;render();announce('Màn hình mô phỏng: '+$('#scenario').selectedOptions[0].textContent);}
function revealRole(){if(!['reveal','night','day','vote','dawn'].includes(state.scenario))return false;state.revealed=true;render();announce('Lá bài riêng đã mở. Dùng nút Che lá bài để cất lại.');return true;}
function setRole(value){if(!Object.hasOwn(roleData,value))throw new RangeError('Unsupported role');state.ownRole=value;state.charges={heal:true,poison:true};state.submitted=false;conceal();}
function afterPrivateAction(){state.submitted=true;if(state.ownRole==='Witch'&&state.target!==null)state.charges[state.potion]=false;render();announce('Đã ghi nhận riêng trong mô phỏng. Không gửi mạng.');}
main.addEventListener('click',event=>{
 const control=event.target.closest('button');if(!control||control.disabled)return;
 const action=control.dataset.action;
 if(scenarios.includes(action)){setScenario(action);return;}
 if(control.dataset.mode){state.voteMode=control.dataset.mode;render();return;}
 if(control.dataset.target){state.target=Number(control.dataset.target);render();return;}
 if(control.dataset.privateTarget){state.target=Number(control.dataset.privateTarget);render();return;}
 if(control.dataset.potion){state.potion=control.dataset.potion;state.target=null;render();return;}
 if(control.dataset.replayStep){state.replayStep=Number(control.dataset.replayStep);render();return;}
 switch(action){
 case 'reveal-role':revealRole();break;
 case 'conceal-role':conceal();announce('Lá bài đã được che.');break;
 case 'next-role':setRole(roleKeys[(roleKeys.indexOf(state.ownRole)+1)%6]);announce('Đã đổi vai mẫu. Xem lại lá bài khi sẵn sàng.');break;
 case 'cast-vote':if(state.target!==null&&![0,6].includes(state.target)){state.ballot=state.target;render();announce('Phiếu mô phỏng công khai: '+names[state.ballot]);}break;
 case 'abstain':state.ballot='abstain';render();announce('Trắng phiếu mô phỏng.');break;
 case 'unvote':state.ballot=null;state.target=null;render();announce('Đã rút phiếu mô phỏng.');break;
 case 'submit-night':if(state.revealed&&state.scenario==='night'&&state.ownRole!=='Villager'&&state.target!==null&&!state.submitted)afterPrivateAction();break;
 case 'pass-night':if(state.revealed&&state.scenario==='night'&&state.ownRole!=='Villager'&&!state.submitted){state.target=null;afterPrivateAction();}break;
 case 'retry':state.reconnectError=!state.reconnectError;render();announce(state.reconnectError?'Lỗi kết nối mô phỏng.':'Lần thử mô phỏng.');break;
 case 'next-replay':state.replayStep=(state.replayStep+1)%4;render();break;
 case 'copy':announce('Mã phòng mẫu: TRANG10. Không phải mã phòng hoạt động.');control.textContent='Mã mẫu: TRANG10';break;
 }
});
main.addEventListener('input',event=>{if(event.target.id==='room-name')state.roomName=event.target.value.slice(0,40);});
main.addEventListener('change',event=>{if(event.target.id==='seat-count'){state.seats=Number(event.target.value);render();}});
$('#scenario').addEventListener('change',event=>setScenario(event.target.value));
$('#motion').addEventListener('click',()=>{state.reduced=!state.reduced;syncMotionPreference();announce(reducedMotionQuery.matches?'Hệ thống đang yêu cầu giảm chuyển động.':state.reduced?'Đã giảm chuyển động.':'Đã trở lại chuyển động theo hệ thống.');});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&state.revealed){conceal();announce('Lá bài đã được che.');}});
window.addEventListener('blur',()=>{if(state.revealed)conceal();});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='visible'&&state.revealed)conceal();});
window.designReview=Object.freeze({game:'werewolf',get scenario(){return state.scenario;},setScenario,setRole,reveal:revealRole,conceal,roles:Object.freeze(roleKeys),snapshot(){return {game:'werewolf',scenario:state.scenario,simulated:true,revealed:state.revealed,...(state.revealed?{ownRole:state.ownRole}:{}),publicRoster:publicRoster.slice(0,state.scenario==='lobby'?state.seats:10).map(x=>({...x})),target:state.revealed?state.target:null,ballot:state.ballot,reducedMotion:effectiveReducedMotion(),hasTransport:false,hasRulesReducer:false};}});
syncMotionPreference();
render();
