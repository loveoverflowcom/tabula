# Ma Sói — thiết kế review, revision 04/10/2026

Bộ này là prototype HTML/CSS/MJS mô phỏng ngoại tuyến bằng tiếng Việt. Các nút không gửi mạng; không có game reducer, match socket, bot, chat hoặc voice. Mẫu dữ liệu có thể đọc trong source và devtools: sự che thẻ ở đây minh họa UX, không chứng minh bảo mật của sản phẩm thật.

Nguồn đối chiếu: checkout `tabula` develop `c0a62088c159cc1f20409de41af245c98dcfcfee`, `AGENTS.md`, docs architecture 00/04, `docs/ui/screens/07-werewolf.md`, `docs/games/werewolf.md`, `games/werewolf/src/rules/{role,config,state}.rs`. Nguồn hiện tại chỉ có config/state/events/assignment và metadata; reducer/View/projection/presenter còn thiếu. Phần UI cũ nêu rõ Phase 7; voice Phase 8. ADR-011 và kết luận defer của ADR-0029 vẫn giữ nguyên.

## Các màn hình để review

- Khám phá: shared Tabula shell với biểu tượng lá bài code-native, giới thiệu, hai đường review chính.
- Thiết lập: 6–20 người; phân bố ClassicV1 cố định; Plurality hoặc AbsoluteMajority; thời lượng mặc định có nhãn.
- Phòng chờ: ghế mẫu theo số lượng đã chọn, mã mẫu, không Ready hay quyền Start thật.
- Nhận vai: phần riêng chỉ được tạo sau thao tác xem; Escape/che/mất focus/visibility/đổi màn hình xóa phần riêng khỏi DOM.
- Ban ngày: roster, đoạn thảo luận công khai mẫu, chat/voice có nhãn chưa triển khai.
- Bỏ phiếu: mục tiêu còn sống khác mình; gửi/thay/rút/trắng phiếu mô phỏng; cửa sổ không kết thúc sớm.
- Ban đêm: vùng công khai giống nhau theo mọi vai. Thẻ riêng minh họa sáu vai và các hành động riêng được cho phép.
- Bình minh: chết/role reveal công khai nhưng không nguyên nhân/actor; báo cáo riêng Tiên tri chỉ báo phe sau thao tác xem.
- Kết quả: fixture kết thúc độc lập, 10 vai được công khai, hai Sói đã chết; không tính chiến thắng từ thao tác review.
- Xem lại: bốn mốc công khai độc lập. Không nhật ký, số lần, thứ tự hay thời điểm hành động riêng.
- Kết nối lại/lỗi: mọi phần riêng gỡ khỏi DOM; retry chỉ đổi kịch bản mô phỏng.

Thiết lập/phòng chờ hỗ trợ 6–20 ghế. Từ nhận vai đến kết quả là fixture minh họa 10 ghế riêng biệt; không phải một ván được tạo từ form. Trạng thái cuối, bình minh và timeline là các mẫu độc lập, không có mô phỏng luật trong JavaScript.

## Khóa luật và thông tin

Chỉ `Villager`, `Werewolf`, `Seer`, `Doctor`, `Hunter`, `Witch` — Dân làng, Ma sói, Tiên tri, Bác sĩ, Thợ săn, Phù thủy. ClassicV1 10 ghế: 2 Sói, 1 Tiên tri, 1 Bác sĩ, 1 Thợ săn, 1 Phù thủy, 4 Dân làng. Form 6–20 khớp bảng role.rs.

| Vai | Thiết kế hành động đêm | Giới hạn |
|---|---|---|
| Dân làng | Đợi | Không có Submit hoặc Pass |
| Ma sói | Chọn người còn sống ngoài phe Sói hoặc bỏ qua | Chỉ biết đồng đội; không thấy lựa chọn hay tiến độ đồng đội |
| Tiên tri | Soi người còn sống khác mình hoặc bỏ qua | Dawn chỉ báo phe; không tiết lộ vai cụ thể |
| Bác sĩ | Bảo vệ hoặc bỏ qua; chọn chính mình được | Không lặp cùng mục tiêu hai đêm liền; không chặn độc |
| Thợ săn | Đánh dấu trước người sống khác mình hoặc bỏ qua | Giữ qua Vote của vòng; không bắn sau khi chết/full vision |
| Phù thủy | Chọn một bình cứu/độc hoặc bỏ qua | Cứu mù; không preview nạn nhân Sói; tự chọn được; tối đa một bình/đêm; tiêu ngay khi gửi |

Đêm → Bình minh → Thảo luận → Vote → Dusk là cửa sổ cố định. Mốc thiết kế được ghi tĩnh, không có đồng hồ thật hoặc chuyển pha tự động. Không hiển thị ready count, số người đã dùng năng lực, pending checks, ai đang chờ, hay phân biệt pass/pending của người khác. Không suy ra save success từ zero deaths. Phiếu công khai có thể thay/rút; không self-vote; hòa cao nhất không loại ai.

Người đã chết có full vision theo `Viewer::Seat` sau transition hoàn tất, nhưng không được gửi gameplay command. Khán giả ngoài chỉ nhận dữ liệu công khai. Các nhánh dead-seat và spectator authority chưa được dựng trong prototype này: UI không có nút chuyển Audit, không đọc canonical State.

## Sở hữu DOM, canvas và Rust

| Phần | Chủ sở hữu khi triển khai |
|---|---|
| Discovery, setup, lobby document, tên/IME, full chat/history, kết quả | Leptos DOM shell, schema typed và shared token authority |
| Lá bài, roster/hit regions, phase HUD, target chọn, compact in-match overlay | Werewolf presenter/canvas Macroquad trong document `/play/:match_id` riêng theo ADR-011 |
| Reveal/hover/focus/selection/motion, camera và prefs | Local presentation state; không truyền về canonical State |
| Phân vai, role mechanics, votes, deadline, deaths, victory | Rust pure rules / server authority; JavaScript không nhân bản |
| Dữ liệu riêng | Rust `project`/`view_event` theo viewer/session; một match client, không match socket thứ hai |
| Text entry, trợ năng | DOM input/mirror từ cùng permitted View. Không chép canonical State hoặc đóng gói bí mật toàn bàn |

Các thẻ DOM hiện tại là nguồn thiết kế có thể chỉnh sửa. Chúng không tự phê duyệt thay Macroquad bằng HTML/Pixi hoặc nhúng game vào shell. Giữ ADR-011; lựa chọn iframe/renderer vẫn defer theo #60. Nếu tương lai cần cách sở hữu khác, phải có ADR và evidence riêng.

View/Intent types thật chưa tồn tại: không coi tên callback trong MJS là wire protocol. Đề xuất boundary có generation và viewer-session identity; inbound chỉ được nhận đúng generation, projection revision và authority schema. Loại các reply/event cũ sau dispose, reconnect hoặc viewer change. Thu hồi private UI trước khi mở màn reconnect/public; chỉ hiện lại khi projection mới được phép. Không expose canonical sequence/timing riêng qua public ack metadata — platform ADR Phase 4 vẫn cần giải quyết.

## Input và khả năng tiếp cận

- Semantic button/select/input thật, skip link, heading và focus ring; Enter/Space là thao tác xem chủ động, không tự lật thẻ bằng hover.
- Rerender giữ focus theo control ID/data identity; khi control riêng biến mất, focus quay về nút xem hoặc vùng main hợp lệ. Escape che thẻ tức thì.
- Thẻ riêng bị gỡ khỏi DOM, gồm text, attributes và accessible tree. Che bằng opacity hoặc aria-hidden đơn thuần không đủ.
- Vote và night target có label/pressed/disabled; lý do được giữ bằng text, không chỉ màu. Không kích hoạt control disabled.
- Giảm motion là phép OR giữa yêu cầu OS và tùy chọn nút review, khởi tạo từ media query và đồng bộ khi OS đổi; aria-pressed và snapshot phản ánh giá trị hiệu lực. Không thể tắt yêu cầu giảm của OS qua nút review. Animation/transition tắt; thông tin và hành động vẫn hiện ngay. Không dùng animation để trì hoãn lệnh.
- Các target gameplay tối thiểu 44 CSS px, primary 48–54 px. Toolbar review là công cụ ngoài product và nhỏ hơn. Khi triển khai cần 200% zoom, AT thật, switch input, touch cancellation, no-audio và native parity.
- Timers thật chỉ hiển thị ước lượng deadline được authority cấp; UI không tự đóng pha và không thay đổi thời lượng theo người đã hành động.

## Asset và ngân sách đề xuất

Dashboard, discovery, setup và lobby dùng scheme light Tabula chung, không tải hero riêng. Sau launch,
private card dùng bộ sáu portrait gốc với khung HTML/CSS tái sử dụng, tên/phe/kỹ năng tiếng Việt sống.
`../deck/cards.mjs` và `cards.css` chứa mặt trước, common back opaque và selected outline+label.
Conceal gỡ face/role/faction khỏi DOM; không chỉ giấu bằng CSS. Đây vẫn là fixture review công khai,
không phải production permitted View hoặc biện pháp bảo vệ role assignment.

Atlas `../assets/werewolf-role-art-atlas.webp`: 1536×1024, 547,838 byte (~535 KiB), sáu panel
512×512, decode RGBA8 6 MiB. Exact prompt và official visual references ở `deck-provenance.json`.
Original PNG giữ ngoài source ZIP. Bảy PNG export 960×1440 nằm trong ZIP asset riêng; DPR3 tăng
độ sắc nét chữ/frame sống, không tăng chi tiết portrait gốc. Không sao chép artwork nhà xuất bản.

Hero `../assets/werewolf-hero.webp`: 1536×1024, 225,888 byte (~221 KiB), decode RGBA8 6 MiB,
giữ cho result story scene sau launch. Prompt/provenance/checksum do manifest chung quản lý.
Không dùng emoji làm artwork; role glyphs/điểm ghế phụ trợ là SVG và chữ code-native.

- Không hero trên entry/setup/lobby hoặc pha vote/night. Gallery/atlas đầy đủ chỉ dành cho review, không đưa vào public gameplay projection.
- Atlas mới vượt đề xuất initial story-art ≤300 KiB. Production cần tách asset từng vai được phép, đo load/decode và tránh request tạo side channel; chưa có variant mobile trong gói này.
- Chi phí code/assets đo theo byte source trong manifests, không phải WASM bundle budget hoặc benchmark. Không có graphics/runtime dependency trong fixture.
- Runtime pack thật phải có license/manifest/version/hash/byte length/atlas bounds kiểm tra trước decode; release texture/listeners/RAF theo lifetime. Frame/back gốc và AI portrait vẫn cần production quality/budget acceptance riêng.
- Không background audio; âm thanh/voice không thiết kế thành capability hoạt động. Audio gesture/preferences/dispose/loss-of-focus phải được thử ở slice thật.

## Các lát triển khai tiếp theo

1. Duyệt ngôn ngữ/thẩm mỹ và affordance reveal; chốt bộ token/shape/components dùng chung. Không sửa game rules trong lát này.
2. Hoàn tất headless Werewolf reducer, project/view_event, SecretModel và event-nonexistence/noninterference theo Phase 3; xác nhận fixed deadlines và stale inputs. Tách ack metadata/private timing theo ADR Phase 4 trước protocol freeze.
3. Một slice private card + roster với permitted View fixture do Rust tạo; implement GamePresentation/Local/Intent ở gate Phase 7 đã được mở. Không đưa canonical State hoặc role assignment table vào client mock production.
4. Nối dispatcher/input focus, keyboard/touch cancellation, DOM mirror/a11y; test viewer switch/reconnect/spectator/dead seat và stale generations. Rerender/bounds từ cùng projection.
5. Asset pack + load/error/dispose; actual desktop/phone Chrome/Safari/native runtime, DPI và reduced-motion. Không đổi renderer/embedding chỉ dựa trên screenshot.
6. Chỉ sau nền tảng hợp lệ: một match socket, authoritative phase/vote/night actions, reconnect and private event omission; sau đó chat socket scopes Phase 7 và voice authorization/SFU Phase 8. Test 12 người thật và second-engineer leak review.

## Bằng chứng và giới hạn

`node --check werewolf.mjs` PASS. Source audit độc lập và actual browser pixel/interaction checks được ghi ở ledger chung của gói; không gọi source scan là runtime/privacy proof. Multiplayer/server/real rules/replay reconstruction/voice/socket permissions không được triển khai hoặc chạy. Không thay Safari settings, không deploy, không push repo.

## API review cho QA

`window.designReview`: `game`, `scenario`, `setScenario(name)`, `setRole(role)`, `reveal()`, `conceal()`, `snapshot()`, `roles`. `setRole` chỉ chọn mock riêng và luôn che thẻ. `snapshot()` khi concealed không trả ownRole; publicRoster không có role. `#public-night` là vùng công khai phải có DOM giống nhau khi đổi vai/action riêng. Các API chỉ dùng review và phải bỏ khỏi production.
