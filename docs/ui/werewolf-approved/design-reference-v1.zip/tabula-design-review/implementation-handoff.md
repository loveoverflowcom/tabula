# Implementation handoff — review trước, game thật sau

Base source: `c0a62088c159cc1f20409de41af245c98dcfcfee`. Đây là thiết kế,
fixture công khai và local UI simulation; chưa có game playable, server, socket,
WASM reducer, projection hay chat/voice mới. Không thay `develop`.

## DOM / canvas / authority

| Owner | Trách nhiệm | Boundary |
|---|---|---|
| Rust rules + authority | legality, phase, accepted transition, deterministic replay, outcome | Canonical State ở authority; never send State/bag/private roles to UI |
| Rust projection | per-viewer View/ViewEvent, public roster/ballots, own role/actions, permitted result | Unauthorised private event must be absent, including occurrence/timing/progress |
| Game presentation | local cursor/selection/preview/camera/motion; typed intent | Never decides a legal move, winner, phase or death |
| Leptos DOM shell | discovery, setup/lobby, forms/text entry, full chat/history and out-of-match result | Remains a separate shell document under ADR-011; no interleaved game canvas or second match client |
| Gameplay presenter + Macroquad | board/marks, roster, phase HUD, private card and in-match targets through existing RenderList seam | Lives in the separate gameplay document; consumes permitted facts; decorative art has no rule meaning |
| Gameplay DOM accessibility mirror | semantic descriptions, Board Reader/actions and necessary text input from the same permitted View | A proposed companion inside the gameplay document, subject to its own integration verification; clears private content on viewer/session/generation changes |

ADR-0029 mới giữ lại Macroquad và ADR-011 hiện có, với shell/gameplay ở hai document riêng. The HTML/CSS/mjs review
is a design surface, not a decision to move the production canvas into Leptos or
to choose Pixi. #60 ADR-0029 defers migration. A later isolated WASM/DOM bridge
needs its own comparable measurements and phase approval before production use.
No second match socket or separate JS rules/state mirror.

## Concrete slices and gates

1. Review visual direction, illustration crop, mobile board density and private
   reveal affordance. Map accepted decorative extensions into authored theme
   tokens; derive CSS/Rust adapters rather than forking production colours.
2. Caro: settle board/rule variant first. At its Phase-3 gate implement GameRules,
   module, valid config, projection and conformance/replay/transactional rejection
   tests. Only then build the game-owned presenter and typed command contract.
3. Werewolf: extend current W1/W2 foundations at Phase 3 with reducer, safe
   per-viewer projection, event omission and security/conformance cases. Six
   existing roles only. Preserve blind Witch heal, Hunter target precommit,
   no self-vote, fixed phase windows and generic public night waiting.
4. Implement lifecycle/contract in an isolated WASM example: generated Rust DTO
   schema, session/generation/view revision, init/dispose/cancel, exact-source
   input, stale intent guard, resize/DPI/focus/context-loss and error receipts.
   Reuse the local #60 fixture protocol; the native HTTP shim is not shipping FFI.
5. Build Caro board and DOM accessible mirror from permitted facts. Adapt key,
   pointer/touch and explicit confirmation to the same typed intent; server
   acceptance changes the board, rejected input preserves state. Test occupied,
   wrong-turn/terminal/out-of-range, cancellation and duplicate activation.
6. Werewolf presentation/social/online at Phase 7 after Phases 4/5. The in-match
   card and its DOM accessibility mirror only receive own authorized role; stale content clears on session/viewer switch,
   reconnect and phase changes. Never download canonical roster roles and filter
   them locally. Chat scopes/socket enforcement and voice Phase 8 remain separate.
7. Execute real Chrome + Safari/WebKit/native controls, matched assets/workloads,
   cold/warm startup/frame/input/copy/serialization measures and 50 lifecycle
   cycles. Report failed/blocked targets; do not infer runtime from a WASM build.

## Input, accessibility and motion

Keep semantic DOM buttons ≥44dp (primary actions ≥48dp), visible focus, logical
Tab order, roving grid focus, coordinate + mark labels, last-move identity and
status updates. Large production Caro boards need zoom/nearest-cell disambiguation
if cells would be smaller than 44dp; the review grid does not decide board size.
Don't rely on X/O colour or subtle animation alone. Public night messages and
render timing must not reveal another player's actions, readiness or save event.
Reduced motion disables decorative transitions and preserves every result/focus
cue. Current keyboard/DOM checks do not certify native screen readers or full
Board Reader dispatch. A future timer displays authoritative deadline estimates;
it never advances phase or reveals private completion.

## Assets and private card implementation

Common dashboard/discovery/setup/lobby use shared light Tabula tokens. Launched
scenes apply each game's review palette. The04.10 revision integrates the complete
six-role deck in `deck/cards.mjs` and `deck/cards.css`; names, factions and skill copy
are editable text. The common back contains no role/faction/face nodes. Reveal renders
only the fixture's selected own role; conceal removes it. This is a visual interaction
contract, not a production data boundary. Real gameplay must render from permitted
Rust View and clear stale content when viewer/session/generation changes.

Atlas1536×1024 /547,838B WebP /~6MiB RGBA8, with six512×512 portrait panels. It is
review-only and exceeds the earlier300KiB initial-art proposal. The next implementation
must author per-role authorized assets and measure loading/decoding, avoid full-atlas
initial loading, and keep private fetches from creating an unauthorized role side
channel. Do not ship the review gallery, static mock role definitions or full deck
atlas as a substitute for projection. Hashes and byte counts are in asset-manifest.json.
Original PNG retained outside lightweight ZIPs; card exports960×1440 use live text at
DPR3 without increasing original portrait detail. Fonts remain system fonts.

Witch uses blind heal, one heal and one poison per match, at most one potion per night;
submission consumes a potion even when ineffective. Hunter precommits during night,
with no new chooser after death. Doctor cannot protect the same target consecutively
and does not block poison. Full behavior remains owned by the source specification,
not shortened card summaries or external tabletop rulebooks. Official publisher decks
were visual references only; new art, frame and back are original review assets.

## Review decisions

1. Caro warm ivory/teal/coral and Werewolf ink/lavender/amber: keep this contrast?
2. Expressive serif headings + compact sans controls: keep, or use sans throughout?
3. Mobile Caro: scrollable ≥44dp sample board now; future larger board should use
   explicit zoom/nearest-cell confirmation after real board-size decision.
4. Werewolf private reveal: press-to-open plus explicit conceal, no automatic
   animation gate; public waiting stays generic for all roles.
5. Approve the design direction before the separately scoped playable slices.
