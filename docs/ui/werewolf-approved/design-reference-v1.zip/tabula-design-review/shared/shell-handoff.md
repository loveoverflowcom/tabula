# Common shell and game style boundary — review revision

The dashboard, discovery, setup and lobby use the same light Tabula scheme. Values in
`shell.css` match `shared/tabula-canonical-tokens.json` (`schemes.light`), including
surface `#FFFBFF`, primary `#5634BE`, and their on-colours. This is an isolated design
adapter, not a change to the canonical authored token source or production routes.

`applySurface(game, scenario)` marks `body[data-surface="shell"]` for `entry`, `setup`
and `lobby`. All launched review scenarios use `body[data-surface="game"]` and the
game's existing palette. Returning through the shared Tabula logo goes back to the
common dashboard. This explicit marker is also the screenshot/verification seam.

Dashboard and discovery use restrained code-native purple board/card symbols. They
do not load bespoke game hero assets. Caro's setup no longer includes the hero asset;
the illustration appears as a small vignette after launch. Werewolf pre-game story
portrait wrappers have been removed; the launched private card uses the new deck.

## Files and integration

- `shared/shell.mjs`: shared brand/header, discovery markup, dashboard rendering and
  surface switching. It carries no match authority or rules reducer.
- `shared/shell.css`: common scheme and responsive shared components; pre-game adapters
  for existing forms and lobby. Read after each game's stylesheet.
- Root `index.html`: common dashboard.
- `caro/index.html`, `caro/app.mjs`, `caro/style.css`: integrated common entry/setup,
  shared navigation, explicit surface switching and game-only artwork vignette.
- `werewolf/index.html`: common header placeholder and common stylesheet installed.

Werewolf integration is complete: `werewolf.mjs` imports the shared discovery and
surface functions, removes setup/lobby portraits, and calls `applySurface` during
render. Its private card uses the reusable deck components. The two actual capture
receipts cover the common→game boundary for both games.

## Evidence

`node verification/capture-shell.mjs` ran with existing Playwright 1.62.1 and headed
Chrome 154.0.8037.97. It passed 12 non-empty viewport/scenario observations (dashboard,
Caro entry, setup and playing at 1440, 390 and 320px), and keyboard launch plus
dashboard-return checks at each size. Document bounds had no horizontal overflow.
Common scenes had the canonical light surface/primary and no story images; gameplay
had Caro's warm surface and one game-only illustration. No page errors were recorded.

Desktop dashboard, phone dashboard, and phone Caro gameplay screenshots were inspected
for hierarchy, legible Vietnamese text, game artwork boundary and clipping. Review
captures use the available Mac system fonts; font metrics on other systems remain
unverified. The companion shared-werewolf-capture verified Werewolf integration with eight
observations and two keyboard launch/return checks. Real gameplay, network,
native/Safari, physical touch and assistive technologies remain unverified.
All runtime state remains explicitly simulated.
