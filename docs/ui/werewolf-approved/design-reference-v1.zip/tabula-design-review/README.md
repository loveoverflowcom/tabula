# Tabula — design review / 04.10.2026

Revision of the03.10 review; the original folder is preserved. Source checked at
`tabula @ c0a62088c159cc1f20409de41af245c98dcfcfee`; repository unchanged.

Dashboard, discovery, setup and lobby share Tabula's canonical light scheme. Each
game's story palette begins after launch. The complete Ma Sói deck has six original
portraits, editable Vietnamese names/factions/ClassicV1 skills and one opaque common
back. The private card is absent from the DOM until the review reveal gesture.

These are interactive design fixtures, **not working multiplayer games**. No rules
reducer, permitted Rust View, match socket or production route is implemented here.
ADR-011/Macroquad remains in place and ADR-0029 keeps renderer migration deferred.

```sh
python3 -m http.server 8063 --bind 127.0.0.1
```

Open `http://127.0.0.1:8063/`, `/caro/`, `/werewolf/`, or `/deck/`.
For phone card states use `/deck/?mobile=Witch`; Enter reveals, the explicit review
selection button adds an outline and label, and Escape conceals. No npm, CDN, font
download or installation is required. Extract both review ZIPs into the same root
for both dashboard links; a single package supports its own game directly.

- `shared/`: common dashboard, navigation, shell styles and source token snapshot.
- `caro/`, `werewolf/`: game fixtures and implementation handoff.
- `deck/`: reusable HTML/CSS frame, six definitions, common back and gallery.
- `assets/deck-provenance.json`: exact built-in imagegen prompt, official visual
  references and distribution limits. Commercial publisher art is not included.
- `previews/`: actual headed Chrome captures, including all six fronts plus back.
- `verification/`: scripts, receipts, asset hashes and tested limitations.

The lightweight Werewolf ZIP includes editable deck source and the optimized atlas;
the seven960×1440 PNG exports and preview captures are separate deliverables. Live
text is rendered at export density; each original portrait panel is512×512. Original
atlas PNG is retained locally outside the ZIP. The full atlas/gallery is review-only,
and must not become a public gameplay projection or a client-side private-role filter.

Shared shell uses source scheme values. Game decorative extensions still require
mapping into the token authority before production implementation. System typography
varies across platforms; screenshots establish this Mac's Chrome rendering only.
